# Task Manager

個人任務管理系統。單人使用,網頁版,支援響應式。

本專案同時是一個**一人團隊開發流程的模擬練習** —— 由同一人扮演
PM、設計、後端、前端、DevOps 五種角色,並遵守真實團隊的流程紀律。

---

## 技術棧

| 層 | 技術 |
|---|---|
| 後端 | Laravel 11 · PHP 8.3 |
| 資料庫 | SQLite（本機)/ PostgreSQL（正式) |
| 前端 | React · Vite · Tailwind CSS |
| 認證 | Laravel Sanctum |
| 測試 | Pest / PHPUnit |
| 部署 | 前端 Vercel · 後端 Railway |

---

## 快速開始

### 需求

- PHP 8.2+
- Composer
- Node.js 20+

> Windows / macOS 建議直接安裝 [Laravel Herd](https://herd.laravel.com),
> 內建 PHP、Composer、Node,免自行設定環境變數。

### 後端

```bash
cd task-api
composer install
cp .env.example .env
php artisan key:generate
php artisan migrate --seed
php artisan serve
```

預設跑在 http://localhost:8000

### 前端

```bash
cd task-web
npm install
cp .env.example .env
npm run dev
```

預設跑在 http://localhost:5173

### 執行測試

```bash
cd task-api
php artisan test
```

---

## 專案結構

```
task-manager/
├── task-api/          Laravel API
├── task-web/          React 前端
├── docs/              規格與流程文件
└── .github/           Issue / PR 範本、CI 設定
```

---

## 文件

| 文件 | 內容 |
|---|---|
| [一人團隊操作手冊](docs/一人團隊操作手冊.md) | 五頂帽子的職能、產出、紀律 |
| [GitHub 設定指南](docs/github-setup.md) | branch protection、labels、看板、PR 流程 |
| [PRD](docs/PRD.md) | 產品需求與範圍 |
| [API 規格](docs/api-spec.md) | 端點、參數、回應、錯誤碼 |
| [資料模型](docs/erd.md) | 資料表與關聯 |
| [部署說明](docs/deployment.md) | 部署步驟與環境變數清單 |

---

## 開發流程

所有變更透過 Pull Request 進入 `main`,**不允許直接 push**。

```
開分支 → commit → push → 開 PR → 【隔天】自我 review → squash merge
```

- 分支命名:`<type>/<issue編號>-<英文簡述>`
- Commit 格式:[Conventional Commits](https://www.conventionalcommits.org/)
- 一張票一個分支,merge 時使用 Squash

詳見[一人團隊操作手冊](docs/一人團隊操作手冊.md)。

---

## 功能範圍

### M1 · MVP 可用

- 任務的新增、編輯、刪除
- 三種狀態:待辦 / 進行中 / 完成
- 依狀態、專案、逾期篩選
- 專案分類
- 側邊欄數量統計

### 不做

多人協作 · 通知提醒 · 原生 App · 重複任務
