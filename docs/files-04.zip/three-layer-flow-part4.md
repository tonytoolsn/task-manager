# 三層主流程：整合非工程師與工程師文件（Part 4）

> 承接 Part 1–3。這一份解決一個具體問題：
> **如何讓非工程師與新手工程師讀同一件事，卻各自得到自己要的？**
>
> 答案不是把兩份文件合併，而是讓它們共用同一根主軸。

---

## 目錄

1. [為什麼整份合併會失敗](#1-為什麼整份合併會失敗)
2. [真正該共用的三樣東西](#2-真正該共用的三樣東西)
3. [三層主流程：設計原理](#3-三層主流程設計原理)
4. [範本 A：Layer 0 使用者旅程](#4-範本-alayer-0-使用者旅程)
5. [範本 B：Layer 1 系統流程](#5-範本-blayer-1-系統流程)
6. [範本 C：Layer 2 程式追碼](#6-範本-clayer-2-程式追碼)
7. [範本 D：名詞表（翻譯層）](#7-範本-d名詞表翻譯層)
8. [範本 E：狀態機（三方共用）](#8-範本-e狀態機三方共用)
9. [範本 F：功能↔模組對照表](#9-範本-f功能模組對照表)
10. [單一文件內的漸進揭露](#10-單一文件內的漸進揭露)
11. [維護：對抗三層漂移](#11-維護對抗三層漂移)
12. [依規模的採用建議](#12-依規模的採用建議)
13. [導入步驟](#13-導入步驟)

---

## 1. 為什麼整份合併會失敗

非工程師和新手工程師要的不只是「詳細程度」不同，是**認知目標**不同。

| | 非工程師 | 新手工程師 |
|---|---|---|
| 讀完要能做什麼 | 判斷「這件事該找誰、能不能做」 | 找到「我該改哪個檔案」 |
| 對細節的態度 | 檔案路徑是噪音 | 檔案路徑是重點 |
| 最怕什麼 | 看到程式碼就關掉 | 看完還是不知道從哪下手 |
| 閱讀方式 | 從頭讀一次，之後不再回來 | 反覆查閱，跳著讀 |
| 成功指標 | 開會時能講對話 | 三天內送出第一個 PR |

一份文件同時塞這兩種，結果是：

- 非工程師在第三段看到 `src/domain/order.ts:42` 就放棄
- 工程師覺得前面五段在浪費時間，直接往下捲

**所以文件要分開。但分開之後會產生新問題：兩邊講的是同一件事，卻對不上。**

這才是要解決的問題。

---

## 2. 真正該共用的三樣東西

真正該「合併」的不是文件，是**底層的共同語言**。

有三個東西天生就服務兩種讀者，它們是整合的樞紐。

### (1) 名詞表 — 中英對照就是翻譯層

它讓「業務講的詞」和「程式裡的名字」有一對一的映射。

有了這張表，PM 說「鎖庫存怎麼會失敗」，工程師立刻知道要去看 `StockReservation`。

**這就是合併的本質——不是合併文件，是合併詞彙。**

### (2) 狀態機 — 業務狀態就是程式狀態

同一張表，不同欄位服務不同人。
QA 拿來設計測試、客服拿來回答客戶、工程師拿來改程式。

一份文件三種人用而不衝突，因為它是 **Reference**（查詢用），不是敘述。

### (3) 功能 ↔ 模組對照表

讓非工程師問對地方，也讓新人知道功能落在哪個目錄。

---

## 3. 三層主流程：設計原理

挑**同一條**核心流程，寫成三層，**共用步驟編號和共用名詞**。

### 三層的分工

| 層 | 檔案 | 語言 | 讀者 | 出現什麼 | 不出現什麼 |
|---|---|---|---|---|---|
| **Layer 0** | `docs/00-overview/user-journey.md` | 業務語言 | PM、客服、營運、設計師 | 使用者看到什麼、耗時、影響 | 服務名稱、檔案路徑、程式碼 |
| **Layer 1** | `docs/01-architecture/order-flow.md` | 系統語言 | 工程師（全體）、架構討論 | 服務、API、同步/非同步、失敗處理 | 檔案路徑、行號、實作細節 |
| **Layer 2** | `docs/02-development/walkthrough.md` | 程式語言 | 新手工程師 | 檔案路徑:行號、程式片段、常見錯誤 | 業務背景（連回 Layer 0） |

### 讓它成為「一份」的三個機制

| 機制 | 做法 | 效果 |
|---|---|---|
| **共用步驟編號** | ①②③④⑤ 三層一致 | 講「第②步」大家指的是同一件事 |
| **共用名詞** | 三層都用名詞表的詞 | 不出現「鎖庫存 / hold / reservation」三種講法 |
| **雙向連結** | 每一層都能往上往下跳 | 讀者可以自己選擇深度 |

### 效果

跨部門開會時：

> PM：「第②步太慢，能不能改？」
> 工程師：（直接跳到 `walkthrough.md#step-2`）「這一步是同步呼叫庫存服務，
> 要改成非同步的話，使用者就不能即時知道有沒有貨了。」

**這就是合併真正的價值——不是省下一份文件，是建立共同座標系。**

### 關係圖

```mermaid
graph TB
    G[glossary.md<br/>名詞表 · 翻譯層]

    L0[Layer 0<br/>user-journey.md<br/>業務語言]
    L1[Layer 1<br/>order-flow.md<br/>系統語言]
    L2[Layer 2<br/>walkthrough.md<br/>程式語言]

    S[state-machine.md<br/>狀態機 · 三方共用]
    M[feature-map.md<br/>功能↔模組]

    G -.名詞來源.-> L0
    G -.名詞來源.-> L1
    G -.名詞來源.-> L2

    L0 <-->|步驟①②③| L1
    L1 <-->|步驟①②③| L2

    S -.-> L0
    S -.-> L2
    M -.-> L0
    M -.-> L2
```

---

## 4. 範本 A：Layer 0 使用者旅程

**檔案**：`docs/00-overview/user-journey.md`

````markdown
# 使用者旅程

> **維護者**：@product-owner ｜ **最後更新**：2026-08-21
> **讀者**：PM、客服、營運、設計師
> **技術細節**：本頁刻意不含程式資訊。想了解系統怎麼實作 →
> [系統流程](../01-architecture/order-flow.md)

本頁使用的名詞以 [名詞表](glossary.md) 為準。

---

## 旅程一：消費者下單（順利情況）

| 步驟 | 使用者看到 | 系統在做什麼 | 耗時 |
|---|---|---|---|
| **①** | 點「結帳」 | 建立訂單，檢查商品與價格是否正確 | < 0.3 秒 |
| **②** | 看到「處理中」 | **預扣庫存**（避免同時有人買走） | < 0.5 秒 |
| **③** | 跳轉到金流頁面 | 訂單進入「待付款」，開始 15 分鐘計時 | — |
| **④** | 輸入卡號、送出 | 由金流系統處理，訂單服務在等 | 3–10 秒 |
| **⑤** | 看到「訂單成立」 | 真正扣庫存、通知倉儲、發確認信 | < 1 秒 |

> 想知道每一步技術上怎麼做 → [系統流程](../01-architecture/order-flow.md)

### 各步驟的業務意義

**① 建立訂單**
這時候訂單就已經存在於系統裡了，即使使用者後來沒付款。
客服可以查到這筆「待付款」的紀錄。

**② 預扣庫存**
「預扣」不等於「扣除」。庫存報表上這是兩個不同欄位。
預扣的目的是避免超賣——在使用者填卡號的這幾分鐘，別人不能買走同一件。

**③ 15 分鐘計時**
這個數字是產品決定的，不是技術限制。
太短使用者來不及付款，太長會鎖住庫存影響其他人。

**⑤ 訂單成立**
到這一步才真的扣庫存。從這一刻起訂單才會出現在倉儲的待出貨清單。

---

## 旅程二：15 分鐘內未付款

| 步驟 | 使用者看到 | 系統在做什麼 |
|---|---|---|
| **①–③** | 同上 | 同上 |
| **④'** | 停留太久後送出付款，看到「訂單已逾時」 | 預扣已釋放，訂單狀態改為「已逾時」 |
| **⑤'** | 回到購物車重新下單 | 建立**新**訂單（不會沿用舊的） |

### 客服常見狀況

**客戶說「我明明有付款」**

1. 請查金流系統是否有成功紀錄
2. 若金流成功但訂單已逾時 → 屬於例外狀況，走人工補單流程
3. 這種情況每月約 3–5 筆，通常是使用者在逾時前一秒送出

**客戶問「為什麼我的訂單不見了」**

已逾時的訂單不會消失，只是狀態變成「已逾時」。
在客服後台把篩選條件的「已逾時」勾起來就能看到。

---

## 旅程三：出貨後想退貨

| 步驟 | 使用者看到 | 系統在做什麼 |
|---|---|---|
| **①** | 在訂單頁點「申請退貨」 | 建立退貨單，訂單狀態不變 |
| **②** | 收到退貨標籤 | 通知逆物流 |
| **③** | 寄回商品 | 等待倉儲驗收 |
| **④** | 收到「退款處理中」 | 倉儲驗收通過，觸發退款 |
| **⑤** | 款項回到原支付方式 | 由金流系統處理，3–7 個工作天 |

> **注意名詞區別**：
> 「取消」是出貨前，「退貨」是出貨後。兩者都會觸發「退款」。
> 詳見 [名詞表](glossary.md#取消-vs-退貨-vs-退款)。

---

## 訂單狀態一覽

完整狀態定義與轉移規則 → [狀態機](../01-architecture/state-machine.md)

| 客戶端顯示 | 意思 | 客戶可否取消 | 客服可否代為取消 |
|---|---|---|---|
| 待付款 | 已下單未付款 | 可 | 可 |
| 處理中 | 已付款，倉儲準備中 | 可 | 可（需主管審核） |
| 已出貨 | 已交給物流 | 不可 | 不可，走退貨 |
| 已完成 | 簽收後 7 天 | 不可 | 不可 |
| 已取消 | — | — | — |
| 已逾時 | 15 分鐘未付款 | — | — |

---

## 這條流程的已知限制

| 限制 | 業務影響 | 有計畫要改嗎 |
|---|---|---|
| 一張訂單最多 100 個品項 | 大宗採購客戶需拆單 | 目前沒需求 |
| 訂單成立後不能改品項 | 客戶只能取消重下 | 2026Q4 評估中 |
| 不支援跨幣別 | 無法服務海外客戶 | 視海外拓展計畫 |
| 15 分鐘無法針對特定客戶調整 | VIP 客戶也一樣逾時 | 已提需求 #445 |
````

---

## 5. 範本 B：Layer 1 系統流程

**檔案**：`docs/01-architecture/order-flow.md`

````markdown
# 訂單流程（系統視角）

> **維護者**：@tech-lead ｜ **最後更新**：2026-08-21
> **讀者**：工程師（全體）、架構討論
>
> **上一層**：[使用者旅程](../00-overview/user-journey.md)（業務視角，無技術細節）
> **下一層**：[程式追碼](../02-development/walkthrough.md)（含檔案路徑）
>
> 步驟編號 ①②③④⑤ 與上下兩層一致。

---

## 全景

```mermaid
sequenceDiagram
    autonumber
    participant U as 前台網站
    participant O as 訂單服務
    participant C as Catalog Service
    participant I as Inventory Service
    participant P as Payment Service
    participant K as Kafka
    participant W as 倉儲系統

    U->>O: ① POST /orders
    O->>C: 驗價（同步，3s timeout）
    C-->>O: 價格與商品資訊
    O->>I: ② 預扣庫存（同步，冪等鍵=orderId）
    I-->>O: 預扣成功
    O->>O: 寫入 orders + outbox（同一交易）
    O-->>U: ③ 201 Created，訂單編號

    Note over U,P: ④ 使用者在金流頁面操作

    P->>K: payment.succeeded
    K->>O: ⑤ 消費付款成功事件
    O->>I: 確認扣庫存
    O->>K: order.paid
    K->>W: 倉儲接收出貨需求
```

---

## ① 建立訂單

**入口**：`POST /orders`

| 項目 | 內容 |
|---|---|
| 認證 | Bearer token（前台代使用者呼叫） |
| 冪等性 | 支援 `Idempotency-Key` header，24 小時內重送回相同結果 |
| 驗證 | 格式驗證（欄位型別、必填）在 API 層；業務驗證在 domain 層 |
| 交易邊界 | 從這裡開始開啟 DB 交易，直到步驟②結束 |

**驗價**：同步呼叫 Catalog Service

- Timeout 3 秒，熔斷器連續 5 次失敗開路 30 秒
- 失敗 → 整筆 rollback，回 503
- **為什麼不快取價格**：促銷檔期價格變動頻繁，快取造成的價差爭議成本
  高於多一次呼叫。見 [ADR-0011](../05-decisions/adr/0011-no-price-cache.md)

> 程式細節 → [walkthrough #step-1](../02-development/walkthrough.md#step-1)

---

## ② 預扣庫存

**呼叫**：`POST inventory-service/reservations`（同步 HTTP）

| 項目 | 內容 |
|---|---|
| 冪等鍵 | `orderId`，重送不會重複預扣 |
| Timeout | 2 秒 |
| 有效期 | 15 分鐘，由 Inventory Service 自行過期 |
| 失敗處理 | 回 409 `INVENTORY_UNAVAILABLE`，整筆交易 rollback |

**為什麼是同步**
使用者需要即時知道有沒有貨。非同步預扣會讓「下單成功但其實沒貨」
變成常態，客訴成本更高。見 [ADR-0006](../05-decisions/adr/0006-sync-inventory.md)。

**已知風險**
「預扣成功但訂單寫入失敗」的極少數情況（DB 在步驟②之後掛掉）。
我們接受這個風險，靠 15 分鐘自動釋放兜底。
不引入分散式交易的理由見 [ADR-0004](../05-decisions/adr/0004-no-distributed-tx.md)。

> 程式細節 → [walkthrough #step-2](../02-development/walkthrough.md#step-2)

---

## ③ 回應與計時

訂單寫入成功後回 `201 Created`，同一個 DB 交易內也寫入 `outbox` 表。

**Transactional Outbox**

因為「寫 DB」和「發 Kafka」無法在同一個交易裡：

- 先發 Kafka 再寫 DB → DB 失敗時事件已送出，下游處理一筆不存在的訂單
- 先寫 DB 再發 Kafka → 發送失敗時事件遺失

解法：把事件也寫進 DB 的 `outbox` 表（同一交易），
再由背景 worker 每 500ms 掃描發送。

代價：事件最多延遲 500ms。見 [ADR-0005](../05-decisions/adr/0005-outbox.md)。

> 程式細節 → [walkthrough #step-3](../02-development/walkthrough.md#step-3)

---

## ④ 付款（外部）

訂單服務在這段時間不做任何事，只是等待。

15 分鐘計時由 Inventory Service 的預扣有效期負責，
訂單服務不另外起 timer——**單一真相來源**。

逾時後 Inventory 釋放預扣，並發出 `reservation.expired` 事件，
訂單服務消費後把狀態改為 `EXPIRED`。

---

## ⑤ 付款成功

**觸發**：消費 Kafka 的 `payment.succeeded` 事件

| 項目 | 內容 |
|---|---|
| Consumer group | `order-service-payment` |
| 冪等性 | 以 `eventId` 去重，重複消費安全 |
| 狀態轉移 | `PENDING_PAYMENT` → `PAID`（經狀態機驗證） |
| 後續動作 | 確認扣庫存、發出 `order.paid` 事件 |

**狀態機**
所有狀態轉移集中驗證，非法轉移會拋出 `InvalidTransitionError`。
完整定義見 [狀態機](state-machine.md)。

**失敗處理**
確認扣庫存失敗 → 進入 DLQ，觸發告警 `OrderConfirmFailed`，
需人工介入。處理方式見 [Runbook](../04-operations/runbook.md#訂單狀態卡在處理中)。

> 程式細節 → [walkthrough #step-5](../02-development/walkthrough.md#step-5)

---

## 失敗矩陣

| 失敗點 | 使用者看到 | 系統行為 | 需要人工嗎 |
|---|---|---|---|
| ① Catalog 逾時 | 「系統忙碌，請稍後再試」 | rollback，503 | 否 |
| ② 庫存不足 | 「商品已售完」 | rollback，409 | 否 |
| ② 庫存服務掛 | 「暫停接單」 | 進入保守模式，全面拒單 | 是（需通知營運） |
| ③ DB 寫入失敗 | 「系統忙碌」 | rollback，預扣靠 15 分鐘釋放 | 否 |
| ⑤ 事件遺失 | 訂單卡在「處理中」 | outbox 重試，超過 5 次進 DLQ | 是 |
| ⑤ 確認扣庫存失敗 | 訂單卡在「處理中」 | 告警 + DLQ | 是 |

> 每一項的處理步驟見 [Runbook](../04-operations/runbook.md)

---

## 效能特性

| 步驟 | p50 | p99 | 瓶頸 |
|---|---|---|---|
| ① 驗價 | 40ms | 180ms | Catalog Service |
| ② 預扣 | 30ms | 120ms | Inventory Service |
| ③ 寫入 | 15ms | 60ms | DB |
| **整體** | **90ms** | **380ms** | — |

SLO：p99 < 500ms。目前有 120ms 餘裕。
````

---

## 6. 範本 C：Layer 2 程式追碼

**檔案**：`docs/02-development/walkthrough.md`

````markdown
# 主流程追碼：一筆訂單的旅程

> **維護者**：@tech-lead ｜ **最後更新**：2026-08-21
> **讀者**：到職第 2–3 天的後端工程師
> **預計閱讀**：30 分鐘，建議一邊開 IDE
>
> **上一層**：[系統流程](../01-architecture/order-flow.md)（服務層級，無檔案路徑）
> **最上層**：[使用者旅程](../00-overview/user-journey.md)（業務視角）
>
> 步驟編號 ①②③④⑤ 與上兩層一致。

讀完這份，你應該能自己找到「要改哪個檔案」。

---

## 準備

```bash
make dev
make db-reset
```

在 `src/application/order/create-order.use-case.ts:42` 下中斷點，然後：

```bash
curl -X POST localhost:3000/orders \
  -H 'Content-Type: application/json' \
  -H 'Idempotency-Key: test-001' \
  -d '{"userId":"u_001","items":[{"sku":"SKU-A","qty":2}]}'
```

---

## ① 建立訂單 {#step-1}

> 業務意義 → [user-journey ①](../00-overview/user-journey.md#旅程一消費者下單順利情況)
> 系統設計 → [order-flow ①](../01-architecture/order-flow.md#-建立訂單)

### 1-1 路由

**檔案**：`src/api/routes/order.routes.ts:28`

```typescript
router.post('/orders', validate(CreateOrderSchema), orderController.create)
```

- `validate()` 是 middleware，用 zod 檢查輸入格式
- Schema 在 `src/api/schemas/order.schema.ts`
- **這裡只做格式驗證，不做業務驗證**

> ⚠️ 新人常犯的錯：把業務規則寫進 schema。
> 「金額不能超過 100 萬」不是格式問題，是業務規則，該放 domain 層。

### 1-2 Controller

**檔案**：`src/api/controllers/order.controller.ts:15`

```typescript
async create(req, res) {
  const command = toCreateOrderCommand(req.body, req.user)
  const result = await this.createOrderUseCase.execute(command)
  res.status(201).json(toOrderResponse(result))
}
```

Controller 只做三件事：轉換輸入 → 呼叫 use case → 轉換輸出。

> ⚠️ 如果你發現自己想在 controller 寫 `if`，多半是放錯地方了。

### 1-3 Use Case（指揮中心）

**檔案**：`src/application/order/create-order.use-case.ts:42`

```typescript
async execute(cmd: CreateOrderCommand): Promise<Order> {
  return this.uow.transaction(async (tx) => {
    const priced = await this.catalog.priceItems(cmd.items)      // ①
    const order  = Order.create({ userId: cmd.userId, items: priced })
    await this.inventory.reserve(order.id, order.items)          // ②
    await this.orderRepo.save(order, tx)                         // ③
    await this.outbox.publish(order.pullEvents(), tx)            // ③
    return order
  })
}
```

Use case 負責**編排**，不寫業務規則。

### 1-4 驗價

**檔案**：`src/infrastructure/catalog/catalog.client.ts:30`

```typescript
const breaker = new CircuitBreaker(this.request, {
  timeout: 3000,
  errorThresholdPercentage: 50,
  resetTimeout: 30000,
})
```

失敗 → 整筆交易 rollback，回 503。

### 1-5 建立 Domain 物件（業務規則的家）

**檔案**：`src/domain/order/order.ts:55`

```typescript
static create(props: CreateOrderProps): Order {
  if (props.items.length === 0)   throw new EmptyOrderError()
  if (props.items.length > 100)   throw new TooManyItemsError()
  if (totalAmount(props.items) > 1_000_000) throw new AmountExceededError()

  const order = new Order({ ...props, status: 'PENDING_PAYMENT' })
  order.addEvent(new OrderCreatedEvent(order.id))
  return order
}
```

**注意這個檔案沒有 import 任何框架。** 它是純 TypeScript。

所以它的測試只要 5ms，不需要 DB
→ 看 `src/domain/order/order.test.ts`，這是你之後寫測試的範本。

---

## ② 預扣庫存 {#step-2}

> 業務意義 → [user-journey ②](../00-overview/user-journey.md#各步驟的業務意義)
> 系統設計 → [order-flow ②](../01-architecture/order-flow.md#-預扣庫存)

**檔案**：`src/infrastructure/inventory/inventory.client.ts:44`

```typescript
async reserve(orderId: OrderId, items: OrderItem[]): Promise<void> {
  await this.http.post('/reservations', {
    headers: { 'Idempotency-Key': orderId },
    body: { items: items.map(toReservationItem) },
    timeout: 2000,
  })
}
```

- 冪等鍵 = `orderId`，重送不會重複扣
- 失敗 → rollback，回 409

> ⚠️ 新人常犯的錯：在這裡加 try-catch 吞掉錯誤。
> 不要。預扣失敗就是不能下單，讓它往上拋。

---

## ③ 存檔與發事件 {#step-3}

> 系統設計 → [order-flow ③](../01-architecture/order-flow.md#-回應與計時)

### 3-1 Repository

**檔案**：`src/infrastructure/persistence/order.repository.ts:80`

- 用 Prisma，schema 在 `prisma/schema.prisma`
- Domain 物件 ↔ DB row 的轉換在 `order.mapper.ts`

### 3-2 Outbox

**檔案**：`src/infrastructure/outbox/outbox.repository.ts:22`

在**同一個交易**內寫入 `outbox` 表。

### 3-3 Outbox Worker

**檔案**：`src/workers/outbox.worker.ts:20`

每 500ms 掃描未送出的列，發到 Kafka 後標記已送出。

為什麼要這麼麻煩 → [ADR-0005](../05-decisions/adr/0005-outbox.md)

---

## ④ 等待付款

訂單服務在這段時間不做任何事。

計時由 Inventory Service 負責，這裡沒有程式。

---

## ⑤ 付款成功 {#step-5}

> 業務意義 → [user-journey ⑤](../00-overview/user-journey.md#各步驟的業務意義)
> 系統設計 → [order-flow ⑤](../01-architecture/order-flow.md#-付款成功)

### 5-1 Consumer

**檔案**：`src/workers/payment-event.consumer.ts:35`

```typescript
async handle(event: PaymentSucceededEvent) {
  if (await this.dedupe.seen(event.id)) return    // 冪等
  await this.confirmPaymentUseCase.execute({
    orderId: event.orderId,
    paidAt: event.occurredAt,
  })
}
```

### 5-2 狀態轉移

**檔案**：`src/domain/order/state-machine.ts:12`

```typescript
const TRANSITIONS: Record<OrderStatus, OrderStatus[]> = {
  PENDING_PAYMENT: ['PAID', 'CANCELLED', 'EXPIRED'],
  PAID:            ['SHIPPED', 'CANCELLED'],
  SHIPPED:         ['COMPLETED', 'RETURNED'],
  COMPLETED:       [],
  CANCELLED:       [],
  EXPIRED:         [],
  RETURNED:        ['REFUNDED'],
  REFUNDED:        [],
}
```

**要新增狀態？改這裡就好。** 型別系統會逼你補齊其他地方。

改完記得同步更新：
- `docs/01-architecture/state-machine.md`
- `docs/00-overview/user-journey.md` 的狀態表

---

## 你現在應該知道

- [ ] 業務規則寫在 `src/domain/`
- [ ] 編排寫在 `src/application/`
- [ ] 外部呼叫寫在 `src/infrastructure/`
- [ ] 新增訂單狀態 → 改 `state-machine.ts`
- [ ] 新增欄位 → 改 `prisma/schema.prisma` + mapper + domain 物件
- [ ] Domain 層不可以 import 框架（CI 會擋）

---

## 練習題（建議實作，會 review）

1. **實作**：加一個「訂單備註」欄位，從 API 一路存到 DB
2. **實作**：加一條規則——同一使用者 1 分鐘內不得下超過 3 筆訂單
3. **閱讀**：找出訂單取消時，庫存在哪裡被釋放的
4. **閱讀**：如果 outbox worker 掛掉 10 分鐘，會發生什麼事？誰會發現？

第 3、4 題是閱讀題，用來驗證你真的理解了流程。

---

## 下一步

- [測試怎麼寫](testing.md)
- [開發規範](conventions.md)
- [為什麼架構長這樣](../05-decisions/adr/)
````

---

## 7. 範本 D：名詞表（翻譯層）

**檔案**：`docs/00-overview/glossary.md`

三層文件全部以這份為準。**「口語」欄位很重要**——那是大家實際會講的詞，
也是要能被搜尋到的詞。

````markdown
# 名詞表 Glossary

> **維護者**：@tech-lead ｜ **最後更新**：2026-08-21
> **讀者**：全員
>
> 規則：
> - 程式中的類別 / 變數命名，必須採用本表的「英文代號」
> - 與外部溝通時使用「業務用語」
> - 一個詞在會議中被誤解過一次，就該進這張表
> - 發現定義不一致 → 開 issue，不要各自解讀

---

## 核心名詞

| 業務用語 | 口語 | 英文代號 | 定義 | 常見誤解 |
|---|---|---|---|---|
| 訂單 | 一單 | `Order` | 一次結帳行為的紀錄，含 1–N 個訂單品項 | 「一單」有時被用來指「一個包裹」 |
| 訂單品項 | 品項 | `OrderItem` | 訂單中的一列（商品 × 數量） | 同商品不會出現兩列，數量會累加 |
| 出貨單 | 包裹 | `Shipment` | 一次實體出貨，一個物流追蹤號 | **一張訂單可對應多張出貨單** |
| 預扣庫存 | 鎖庫存 | `StockReservation` | 下單時暫時保留，15 分鐘有效 | 預扣 ≠ 扣除，報表上是不同欄位 |

---

## 取消 vs 退貨 vs 退款

**這三個最常被混用，務必區分。**

| 業務用語 | 英文代號 | 發生時機 | 有無物流 | 觸發退款 |
|---|---|---|---|---|
| 取消 | `Cancel` | 出貨前 | 無 | 是 |
| 退貨 | `Return` | 出貨後，商品寄回 | 有（逆物流） | 是 |
| 退款 | `Refund` | 金流動作 | 無關 | — |

一次取消觸發一次退款；一次退貨也觸發一次退款。
**但退款不一定伴隨退貨**（例如商品瑕疵直接退款不收回）。

---

## 縮寫對照

| 縮寫 | 全稱 | 說明 |
|---|---|---|
| SKU | Stock Keeping Unit | 最小庫存單位，含顏色尺寸 |
| SPU | Standard Product Unit | 商品款式，一個 SPU 含多個 SKU |
| GMV | Gross Merchandise Value | 成交總額，含尚未付款的訂單 |
| AOV | Average Order Value | 客單價 |
| DLQ | Dead Letter Queue | 處理失敗的訊息暫存區 |

---

## 已淘汰的名詞

| 舊詞 | 現在叫 | 淘汰時間 | 原因 |
|---|---|---|---|
| 交易單 | 訂單 Order | 2025-03 | 與財會的「交易」概念衝突 |
| 鎖單 | 預扣庫存 | 2025-06 | 語意不清 |
| 廢單 | 已逾時 / 已取消 | 2025-08 | 兩種狀況被混為一談 |

看到舊詞請提醒對方，並確認他指的是哪一個。
````

---

## 8. 範本 E：狀態機（三方共用）

**檔案**：`docs/01-architecture/state-machine.md`

這份文件的特殊之處：**同一張表，不同欄位服務不同讀者。**

````markdown
# 訂單狀態機

> **維護者**：@tech-lead ｜ **最後更新**：2026-08-21
> **讀者**：工程師、QA、客服
> **程式位置**：`src/domain/order/state-machine.ts`
>
> 改動狀態時，必須同時更新本文件與
> [使用者旅程](../00-overview/user-journey.md#訂單狀態一覽)。

---

## 狀態圖

```mermaid
stateDiagram-v2
    [*] --> PENDING_PAYMENT: 建立訂單

    PENDING_PAYMENT --> PAID: 付款成功
    PENDING_PAYMENT --> EXPIRED: 15 分鐘未付款
    PENDING_PAYMENT --> CANCELLED: 使用者取消

    PAID --> SHIPPED: 倉儲出貨
    PAID --> CANCELLED: 出貨前取消（需審核）

    SHIPPED --> COMPLETED: 簽收後 7 天
    SHIPPED --> RETURNED: 申請退貨

    RETURNED --> REFUNDED: 驗收通過

    CANCELLED --> [*]
    EXPIRED --> [*]
    COMPLETED --> [*]
    REFUNDED --> [*]
```

---

## 狀態總表

| 內部狀態 | 客戶端顯示 | 意義 | 客戶可取消 | 客服可取消 | 觸發的事件 |
|---|---|---|---|---|---|
| `PENDING_PAYMENT` | 待付款 | 已下單未付款 | ✓ | ✓ | `order.created` |
| `PAID` | 處理中 | 已付款，倉儲準備中 | ✓ | ✓（需審核） | `order.paid` |
| `SHIPPED` | 已出貨 | 已交給物流 | ✗ | ✗ | `order.shipped` |
| `COMPLETED` | 已完成 | 簽收後 7 天 | ✗ | ✗ | `order.completed` |
| `CANCELLED` | 已取消 | — | — | — | `order.cancelled` |
| `EXPIRED` | 已逾時 | 15 分鐘未付款 | — | — | `order.expired` |
| `RETURNED` | 退貨處理中 | 商品已寄回 | — | — | `order.returned` |
| `REFUNDED` | 已退款 | 退款完成 | — | — | `order.refunded` |

**欄位對誰有用**：

- 「客戶端顯示」「客戶可取消」「客服可取消」→ 客服、PM
- 「內部狀態」「觸發的事件」→ 工程師、QA

---

## 轉移規則與副作用

| 從 | 到 | 觸發條件 | 副作用 |
|---|---|---|---|
| `PENDING_PAYMENT` | `PAID` | 收到 `payment.succeeded` | 確認扣庫存、通知倉儲 |
| `PENDING_PAYMENT` | `EXPIRED` | 收到 `reservation.expired` | 無（預扣已由 Inventory 釋放） |
| `PENDING_PAYMENT` | `CANCELLED` | 使用者或客服操作 | 主動釋放預扣 |
| `PAID` | `SHIPPED` | 倉儲回報出貨 | 記錄追蹤號、發通知信 |
| `PAID` | `CANCELLED` | 客服操作（需主管審核） | 釋放庫存、觸發退款 |
| `SHIPPED` | `COMPLETED` | 簽收後 7 天（排程） | 開放評價 |
| `SHIPPED` | `RETURNED` | 使用者申請退貨 | 產生逆物流單 |
| `RETURNED` | `REFUNDED` | 倉儲驗收通過 | 回補庫存、觸發退款 |

**所有未列出的轉移都是非法的**，會拋出 `InvalidTransitionError`。

---

## 新增狀態的步驟

1. 改 `src/domain/order/state-machine.ts` 的 `TRANSITIONS`
2. 型別錯誤會指出所有需要補的地方，逐一修正
3. 更新本文件的狀態圖與兩張表
4. 更新 [使用者旅程](../00-overview/user-journey.md#訂單狀態一覽) 的狀態表
5. 通知 #commerce-ops（客服後台的篩選選項要加）
6. 加測試：`should_allow_X_to_Y` 與 `should_reject_X_to_Z`

---

## QA 測試重點

| 測試 | 為什麼 |
|---|---|
| 每個合法轉移都能成功 | 基本正確性 |
| 每個非法轉移都被拒絕 | 防止資料汙染 |
| 重複觸發同一轉移是冪等的 | 事件可能重送 |
| 終端狀態不接受任何轉移 | `COMPLETED` 之後不該再變 |
````

---

## 9. 範本 F：功能↔模組對照表

**檔案**：`docs/00-overview/feature-map.md`

讓非工程師問對地方，也讓新人知道功能落在哪。

````markdown
# 功能 ↔ 模組對照表

> **維護者**：@tech-lead ｜ **最後更新**：2026-08-21
> **讀者**：全員
>
> 用途：
> - **非工程師**：想問某個功能的問題時，知道該找誰
> - **新手工程師**：接到需求時，知道該從哪個目錄開始看

---

| 功能 | 使用者怎麼稱呼 | 程式位置 | 負責人 | Slack |
|---|---|---|---|---|
| 建立訂單 | 下單、結帳 | `src/application/order/create-order.use-case.ts` | @alice | #commerce-eng |
| 預扣庫存 | 鎖庫存 | `src/infrastructure/inventory/` | @alice | #commerce-eng |
| 付款確認 | 金流回來 | `src/workers/payment-event.consumer.ts` | @bob | #commerce-eng |
| 訂單取消 | 取消訂單 | `src/application/order/cancel-order.use-case.ts` | @alice | #commerce-eng |
| 退貨 | 退貨、退回 | `src/application/return/` | @carol | #commerce-eng |
| 分批出貨 | 拆單出貨 | `src/domain/shipment/split.ts` | @bob | #commerce-eng |
| 訂單查詢 | 查訂單 | `src/api/routes/order-query.routes.ts` | @alice | #commerce-eng |
| 對帳報表 | 日報 | `src/workers/daily-report.worker.ts` | @dave | #finance-eng |

---

## 不屬於本服務的功能

被問到這些時，請轉給對應團隊：

| 功能 | 誰負責 | Slack |
|---|---|---|
| 刷卡、扣款、退款金流 | Payment Team | #payment-eng |
| 商品價格、上下架 | Catalog Team | #catalog-eng |
| 會員資料、點數 | Member Team | #member-eng |
| 實體出貨、貨運追蹤 | 物流廠商 XYZ | #logistics |
| 發票開立 | 財會系統 | #finance-eng |
| 前台網站畫面 | Frontend Team | #web-eng |
````

---

## 10. 單一文件內的漸進揭露

小專案不想維護三層，可以在一份文件裡分層。
但**只在特定條件下可行**。

### 做法

````markdown
## ② 預扣庫存

訂單建立時會先向庫存服務「預扣」，避免超賣。
15 分鐘沒付款就自動釋放。

<details>
<summary>🔧 技術細節</summary>

**檔案**：`src/infrastructure/inventory/inventory.client.ts:44`

- 同步 HTTP，timeout 2 秒
- 帶 `Idempotency-Key: {orderId}`，重送不會重複扣
- 熔斷器：連續 5 次失敗開路 30 秒
- 失敗 → 整筆交易 rollback，回 409

為什麼是同步 → [ADR-0006](../adr/0006-sync-inventory.md)

</details>
````

### 可行的條件

- [ ] 業務段落**單獨讀完是完整的**（不能是「詳見下方技術細節」）
- [ ] 技術段落不超過主文的 1/3
- [ ] 摺疊區塊不巢狀
- [ ] 全文摺疊區塊不超過 5 個

### 不可行的情況

**兩種讀者要的是不同的組織方式，不只是不同的細節量。**

例如：

| 文件 | 業務視角的組織方式 | 技術視角的組織方式 |
|---|---|---|
| Runbook | 按「業務影響」 | 按「故障類型」 |
| Overview | 按「功能」 | 按「模組」 |
| API 文件 | 按「使用情境」 | 按「endpoint」 |

這些無法用摺疊解決，必須拆成兩份。

### 一個實用的檢查法

> **把技術段落全部刪掉，非工程師讀起來還是完整的嗎？**

- 可以 → 漸進揭露成功
- 不行 → 該拆成兩份

---

## 11. 維護：對抗三層漂移

這是這個設計最大的風險。三層一定會漂移，除非有機制。

### 三個對策

**(1) 只做一條主流程**

貪心做五條，五條都會過期。
一條維護得動的流程 > 五條半死的流程。

如果真的需要第二條（例如退貨流程），
先確認第一條已經穩定維護三個月以上。

**(2) 步驟編號改動時，三層一起改**

寫進 PR 檢查清單：

```markdown
- [ ] 改了主流程的步驟 → user-journey / order-flow / walkthrough 三份一起改
- [ ] 改了訂單狀態 → state-machine.md + user-journey.md 的狀態表
- [ ] 引入新的領域名詞 → glossary.md
```

**(3) 用 AI 定期檢查一致性**

```
請比對 docs/00-overview/user-journey.md、
docs/01-architecture/order-flow.md、
docs/02-development/walkthrough.md 這三份文件，檢查：

1. 步驟編號 ①②③④⑤ 是否三份一致，有沒有某份多了或少了步驟
2. 有沒有使用 docs/00-overview/glossary.md 以外的名詞
   （尤其注意同一概念的不同講法）
3. 交叉連結的錨點（#step-1 等）是否還存在
4. walkthrough.md 中提到的檔案路徑是否還存在

列出所有不一致，標明在哪份文件的第幾行。
```

建議每月跑一次，或在大型重構後跑。

### CI 可以做的檢查

```yaml
- name: 檢查文件連結
  run: npx markdown-link-check docs/**/*.md

- name: 檢查 walkthrough 提到的檔案是否存在
  run: node scripts/check-walkthrough-paths.js
```

`check-walkthrough-paths.js` 的邏輯很簡單：
用 regex 抓出所有 `` `src/xxx.ts:42` `` 格式的路徑，
檢查檔案存在、行數足夠。

---

## 12. 依規模的採用建議

| 規模 | 做法 |
|---|---|
| **小（1–3 人）** | 一份 README + 摺疊區塊。名詞表寫在 README 底部就好。不做三層 |
| **中（4–15 人）** | 名詞表獨立 + 三層主流程（**只做一條**）+ 狀態機 |
| **大（16+ 人）** | 加上功能↔模組對照表、跨團隊統一名詞表、每個服務一條主流程 |

### 中型專案的最小組合（5 份）

```
docs/
├── 00-overview/
│   ├── glossary.md          ← 翻譯層，最先做
│   └── user-journey.md      ← Layer 0
├── 01-architecture/
│   ├── order-flow.md        ← Layer 1
│   └── state-machine.md     ← 三方共用
└── 02-development/
    └── walkthrough.md       ← Layer 2
```

---

## 13. 導入步驟

不要一次做完。這個順序每一步都能單獨產生價值。

### Step 1：名詞表（半天）

**先做這個，因為後面三層都要用它。**

做法：

1. 掃描程式中的類別名、型別名，列成清單
2. 訪問 PM / 客服，問他們平常怎麼稱呼這些東西
3. 找出不一致的地方——那些就是最有價值的條目

```
請掃描 src/domain/ 下所有型別與類別名稱，
去重後依出現頻率排序。我要拿來建名詞表。
```

**驗收**：拿去下一次跨部門會議用。如果有人說「原來這個叫這個」，就成功了。

### Step 2：Layer 2 追碼（一天）

**先做最底層，因為它最容易驗證對錯。**

自己照著走一遍，跑不通就是寫錯了。

```
請追蹤 POST /orders 的完整路徑，從路由到 DB 寫入與事件發送。
每一站包含：檔案路徑:行號、這一站在做什麼、新手常犯的錯。
目標讀者是到職第三天的後端工程師。
```

**驗收**：找一個沒碰過這塊的工程師照著讀，看他能不能完成練習題。

### Step 3：Layer 0 使用者旅程（半天）

**往上抽象**，把 Layer 2 的技術細節全部拿掉，換成使用者視角。

```
根據 walkthrough.md，寫一份給 PM 和客服看的使用者旅程。
保留相同的步驟編號 ①②③④⑤。
不要出現任何檔案路徑、類別名稱、服務名稱。
每一步要說明「使用者看到什麼」和「這一步的業務意義」。
```

**驗收**：拿給 PM 讀，問他「第②步在做什麼」，看他能不能答對。

### Step 4：Layer 1 系統流程（半天）

**填中間層**。這一層最後做，因為它的邊界最模糊
（做完上下兩層才知道中間該放什麼）。

**驗收**：架構討論時能不能直接開這份文件。

### Step 5：加交叉連結（一小時）

三層互相連結，加上步驟編號的錨點。

### Step 6：狀態機（半天）

如果有狀態欄位就做。這份文件三種人都會用。

---

## 附錄：四份文件的關係

| 文件 | 回答什麼 |
|---|---|
| **Part 1**：專案文件架構完整指南 | 該寫哪些文件、長什麼樣 |
| **Part 2**：專案文件策略 | 依規模怎麼調整、什麼時候不該寫 |
| **Part 3**：GitHub 起手式 | 怎麼設定讓規則自動執行 |
| **Part 4**：三層主流程（本文件） | 怎麼讓兩種讀者共用同一根主軸 |

### 本文件的一句話總結

> **不要合併文件，要合併詞彙與座標系。**
>
> 三層分開寫，但共用名詞表、共用步驟編號、互相連結。
> 這樣 PM 說「第②步太慢」時，工程師能立刻跳到對應的程式。
