# GitHub 專案起手式（Part 3）：依規模的完整設定指南

> 承接《專案文件架構完整指南》與《專案文件策略 Part 2》。
> 這一份談：在 GitHub 上，小 / 中 / 大型專案分別該怎麼設定，
> 以及哪些免費功能被低估了。

---

## 核心原則

> **小專案的起手式重點不是「加東西」，是「一次設好就不用再管」。**
>
> 每個需要人記得做的規則，最後都會被忘記。
> 能用設定強制的，不要用文件約定。

三個判準：

| 判準 | 說明 |
|---|---|
| **一次性 > 持續性** | 勾選一次的設定 > 需要每次遵守的規範 |
| **快 > 完整** | CI 慢了就會被跳過。小專案目標是「快到你願意等」 |
| **本機 == CI** | `make check` 要跟 CI 跑一樣的東西，消滅「本機過了 CI 卻紅」 |

---

## 目錄

**第一部：小專案（1–3 人）**
1. [Repo Settings（5 分鐘）](#1-repo-settings5-分鐘)
2. [必備檔案清單](#2-必備檔案清單)
3. [CI 設定](#3-ci-設定)
4. [Dependabot](#4-dependabot)
5. [Ruleset](#5-ruleset)
6. [自動 Release Notes](#6-自動-release-notes)
7. [Devcontainer / Codespaces](#7-devcontainer--codespaces)
8. [小專案不要做的事](#8-小專案不要做的事)

**第二部：中專案（4–15 人）**

9. [增量檔案](#9-增量檔案)
10. [Ruleset 收緊](#10-ruleset-收緊)
11. [Environments 與部署保護](#11-environments-與部署保護)
12. [CI 分工與安全掃描](#12-ci-分工與安全掃描)
13. [自動標籤與 CODEOWNERS](#13-自動標籤與-codeowners)

**第三部：大專案（16+ 人）**

14. [Org 層級的 .github repo](#14-org-層級的-github-repo)
15. [Reusable Workflows](#15-reusable-workflows)
16. [Organization Rulesets](#16-organization-rulesets)
17. [Template Repository](#17-template-repository)
18. [供應鏈安全](#18-供應鏈安全)
19. [Service Catalog](#19-service-catalog)

**第四部：對照與檢查**

20. [規模對照表](#20-規模對照表)
21. [新 Repo 檢查清單](#21-新-repo-檢查清單)
22. [常見錯誤](#22-常見錯誤)

---

# 第一部：小專案（1–3 人）

## 1. Repo Settings（5 分鐘）

不用寫程式，但價值很高。Settings → General：

| 設定 | 建議 | 為什麼 |
|---|---|---|
| **Automatically delete head branches** | ✓ 開 | 免費的整潔。不然半年後有 40 條殭屍分支 |
| **Allow squash merging** | ✓ 只留這個 | 關掉 merge commit 和 rebase，歷史線性好讀 |
| **Default commit message** | `PR title and description` | squash 後的 commit message 才會有內容 |
| **Allow auto-merge** | ✓ 開 | 給 Dependabot 用 |
| **Wiki** | ✗ 關（如果不用） | 少一個「第二個真相來源」 |
| **Projects** | ✗ 關（如果不用） | 同上 |
| **Discussions** | 可選開 | 適合放「為什麼」的長討論，比 issue 適合 |

### 為什麼只留 Squash

小專案的 git 歷史應該是**一個 PR = 一個 commit**。理由：

- `git log --oneline` 讀起來就是功能清單
- `git bisect` 每一步都是可運作的狀態
- 不會有「WIP」「fix typo」「再修一次」污染歷史
- revert 一個功能只要 revert 一個 commit

代價是失去 PR 內部的細部歷史，但小專案幾乎不需要那個。

---

## 2. 必備檔案清單

```
.github/
├── workflows/
│   ├── ci.yml
│   └── dependabot-automerge.yml
├── dependabot.yml
└── release.yml
.devcontainer/
└── devcontainer.json
.editorconfig
.gitignore
.git-blame-ignore-revs
.nvmrc                    # 或 .tool-versions / .python-version
.env.example
Makefile
README.md
DECISIONS.md
CLAUDE.md
LICENSE
```

### .editorconfig

一分鐘的工，省掉所有「換行符號 / 縮排」的無意義 diff：

```ini
root = true

[*]
charset = utf-8
end_of_line = lf
insert_final_newline = true
trim_trailing_whitespace = true
indent_style = space
indent_size = 2

[*.md]
trim_trailing_whitespace = false

[Makefile]
indent_style = tab

[*.{py}]
indent_size = 4
```

### .git-blame-ignore-revs

放大規模格式化、改名的 commit hash，讓 `git blame` 不會全部指向
「某次 prettier 大掃除」：

```
# .git-blame-ignore-revs
# 導入 prettier 全專案格式化
a1b2c3d4e5f6789012345678901234567890abcd
# 全專案 var → const/let
f6e5d4c3b2a1987654321098765432109876dcba
```

啟用（每個人都要跑一次，或寫進 setup script）：

```bash
git config blame.ignoreRevsFile .git-blame-ignore-revs
```

**這是一分鐘的工，救無數次考古。**

### Makefile — 小專案最好的「可執行文件」

```makefile
.DEFAULT_GOAL := help
.PHONY: dev test lint typecheck check clean help

dev:              ## 啟動開發環境
	docker compose up -d
	npm run dev

test:             ## 跑測試
	npm test

test-watch:       ## 監看模式
	npm test -- --watch

lint:             ## 檢查格式
	npm run lint

typecheck:        ## 型別檢查
	npm run typecheck

check: lint typecheck test  ## CI 跑的東西，本機也能跑

db-reset:         ## 重建資料庫並灌測試資料
	npm run db:reset && npm run db:seed

clean:            ## 清掉暫存
	rm -rf node_modules dist .turbo

help:             ## 顯示指令列表
	@grep -E '^[a-zA-Z_-]+:.*?## .*$$' $(MAKEFILE_LIST) | \
	  awk 'BEGIN {FS = ":.*?## "}; {printf "\033[36m%-14s\033[0m %s\n", $$1, $$2}'
```

**關鍵：`make check` 必須跟 CI 跑一樣的東西。**
這樣「本機過了 CI 卻紅」的狀況會消失。

### .env.example

每個變數都要寫：**用途、怎麼拿到、能不能直接用**。

```bash
# ─── 資料庫 ───────────────────────────────
# 本機開發用 make dev 啟動的 container，不需要改
DATABASE_URL=postgresql://dev:dev@localhost:5432/myapp

# ─── 外部服務 ─────────────────────────────
# Catalog Service API key
# 向 #platform-eng 申請，每個環境不同
CATALOG_API_KEY=

# Stripe 測試金鑰
# Stripe Dashboard > Developers > API keys（記得用 test mode）
STRIPE_SECRET_KEY=sk_test_xxxxx

# ─── 選填 ─────────────────────────────────
# 不填則不送 Sentry
SENTRY_DSN=
```

---

## 3. CI 設定

小專案的 CI 慢了就會被跳過。**目標：3 分鐘內。**

```yaml
# .github/workflows/ci.yml
name: CI

on:
  push:
    branches: [main]
  pull_request:

# 同一個 PR 連推兩次，取消舊的（省時間也省額度）
concurrency:
  group: ${{ github.workflow }}-${{ github.ref }}
  cancel-in-progress: true

jobs:
  check:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - uses: actions/setup-node@v4
        with:
          node-version-file: '.nvmrc'
          cache: 'npm'          # ← 這行通常省一半時間

      - run: npm ci
      - run: npm run lint
      - run: npm run typecheck
      - run: npm test
```

### 三個常被漏掉的細節

| 細節 | 效果 |
|---|---|
| `concurrency` + `cancel-in-progress` | 連續 push 時取消舊的 run，省時間也省額度 |
| `cache: 'npm'` | 一行，通常省 30–60 秒 |
| `node-version-file: '.nvmrc'` | 版本只定義在一個地方，CI 與本機不會不同步 |

### 其他語言的版本檔對應

| 語言 | 版本檔 | setup action 參數 |
|---|---|---|
| Node | `.nvmrc` | `node-version-file` |
| Python | `.python-version` | `python-version-file` |
| Go | `go.mod` | `go-version-file` |
| Java | `.java-version` | `java-version-file` |
| 多語言 | `.tool-versions`（asdf/mise） | 需搭配 mise action |

---

## 4. Dependabot

小專案最划算的自動化，但**一定要設 grouping**，
否則每週被 15 個 PR 淹沒然後全部忽略。

```yaml
# .github/dependabot.yml
version: 2
updates:
  - package-ecosystem: "npm"
    directory: "/"
    schedule:
      interval: "weekly"
      day: "monday"
      time: "09:00"
      timezone: "Asia/Taipei"
    open-pull-requests-limit: 5
    groups:
      # 所有小版本更新合成一個 PR
      minor-and-patch:
        update-types: ["minor", "patch"]
      # 主版本各自一個 PR（需要人看）
    commit-message:
      prefix: "chore(deps)"
    labels: ["dependencies", "skip-changelog"]

  # 別忘了 GitHub Actions 本身也要更新
  - package-ecosystem: "github-actions"
    directory: "/"
    schedule:
      interval: "monthly"
    commit-message:
      prefix: "chore(ci)"
```

### 搭配 Auto-merge

Patch 更新且 CI 通過 → 自動合併。
先在 Settings → General 開啟 `Allow auto-merge`，然後：

```yaml
# .github/workflows/dependabot-automerge.yml
name: Dependabot auto-merge

on: pull_request

permissions:
  contents: write
  pull-requests: write

jobs:
  automerge:
    if: github.actor == 'dependabot[bot]'
    runs-on: ubuntu-latest
    steps:
      - uses: dependabot/fetch-metadata@v2
        id: meta

      - name: 自動合併 patch 更新
        if: steps.meta.outputs.update-type == 'version-update:semver-patch'
        run: gh pr merge --auto --squash "$PR_URL"
        env:
          PR_URL: ${{ github.event.pull_request.html_url }}
          GH_TOKEN: ${{ secrets.GITHUB_TOKEN }}
```

`--auto` 表示「CI 通過才合併」，不會盲目合併。

### 分寸拿捏

| 更新類型 | 建議 |
|---|---|
| patch | 自動合併 |
| minor | 人看一眼，通常直接過 |
| major | 一定要人看，可能有 breaking change |
| security | Dependabot 會另外開，優先處理 |

---

## 5. Ruleset

Ruleset 是新版的 Branch Protection（Settings → Rules → Rulesets）。

小專案的兩難：開太嚴會擋到自己，不開又沒保障。

### 建議：只開這兩項

```
Target: main（Include default branch）

✓ Require status checks to pass
    → 勾選 "check"（CI 的 job 名稱）
✓ Block force pushes

✗ Require pull request before merging     ← 小專案先不要開
✗ Require signed commits                  ← 之後再說
✗ Require linear history                  ← squash-only 已經達成
```

### 為什麼不開 Require PR

單人專案時 `require PR` 只是自己批准自己，純儀式。

但 **status check 會擋住壞掉的 code 進 main**，這是真的有用。

**團隊到 3 人時再打開**，且 approvals 設 1。

### 小技巧：Bypass list

如果偶爾需要緊急直推，把自己加進 bypass list，
比整個關掉 ruleset 好——因為 bypass 有紀錄。

---

## 6. 自動 Release Notes

用 Conventional Commits + GitHub 內建功能，零成本。

```yaml
# .github/release.yml
changelog:
  categories:
    - title: ✨ 新功能
      labels: [feature, enhancement]
    - title: 🐛 修正
      labels: [bug, fix]
    - title: ⚡ 效能
      labels: [performance]
    - title: 📝 文件
      labels: [documentation]
    - title: 🔧 其他
      labels: ["*"]
  exclude:
    labels: [skip-changelog]
    authors: [dependabot]
```

使用方式：`Releases → Draft new release → Generate release notes`

它會自動抓 PR 標題依 label 分類。

### 搭配 Conventional Commits

如果 PR 標題遵循 `feat:` / `fix:` / `docs:` 格式，
可以再加一個 action 自動貼 label，或用 release-drafter 全自動化。

小專案手動點一下就夠了，不用引入額外工具。

---

## 7. Devcontainer / Codespaces

小專案特別划算——**它讓「環境建置文件」變成不可能過期**
（過期就跑不起來，馬上有人修）。

```json
// .devcontainer/devcontainer.json
{
  "name": "my-project",
  "image": "mcr.microsoft.com/devcontainers/typescript-node:20",
  "features": {
    "ghcr.io/devcontainers/features/docker-in-docker:2": {},
    "ghcr.io/devcontainers/features/github-cli:1": {}
  },
  "forwardPorts": [3000, 5432],
  "postCreateCommand": "npm ci && cp -n .env.example .env",
  "customizations": {
    "vscode": {
      "extensions": [
        "dbaeumer.vscode-eslint",
        "esbenp.prettier-vscode",
        "Prisma.prisma"
      ],
      "settings": {
        "editor.formatOnSave": true
      }
    }
  }
}
```

有這份，README 的「5 分鐘跑起來」可以縮成一行：

> 點 Code → Codespaces → Create codespace on main

即使不用 Codespaces，本機用 VS Code Dev Containers 開啟也能得到一致環境。

---

## 8. 小專案不要做的事

| 不要 | 為什麼 |
|---|---|
| Issue templates | 三個人用 issue，直接寫就好 |
| PR template | 你自己就是 reviewer |
| CODEOWNERS | 只有你，寫了沒意義 |
| 多環境 + deployment protection | 過度工程 |
| Projects / 看板 | 用 issue 的 label 就夠 |
| 複雜的 branch strategy | `main` + feature branch，不要 gitflow |
| 自架 runner | 免費額度綽綽有餘 |
| Monorepo 工具（Nx/Turbo） | 一個 package 不需要 |
| 語意化版本自動發布 | 沒有外部使用者就不需要 |

**通則**：如果加上去之後你需要「記得」做某件事，而不是「自動」發生，
在小專案就先不要加。

---

# 第二部：中專案（4–15 人）

只列**增量**，前面的全部保留。

## 9. 增量檔案

```
.github/
├── CODEOWNERS                    ← 開始有意義
├── pull_request_template.md      ← 含文件檢查清單
├── labeler.yml                   ← 自動標籤規則
├── ISSUE_TEMPLATE/
│   ├── bug_report.yml
│   ├── feature_request.yml
│   └── config.yml                ← 導流到 Discussions
└── workflows/
    ├── ci.yml                    ← 分 job 並行
    ├── deploy.yml
    ├── security.yml
    └── labeler.yml
```

### pull_request_template.md

```markdown
## 這個 PR 做了什麼

<!-- 一兩句話，給 reviewer 看的 -->

## 為什麼

<!-- 連結 issue，或說明背景 -->

## 怎麼驗證

<!-- reviewer 要怎麼確認這個改動是對的 -->

---

## 文件檢查

- [ ] 改了 API → 更新 `docs/03-api/`
- [ ] 改了資料表 → 更新 `docs/01-architecture/data-model.md`
- [ ] 引入新的領域名詞 → 加入 `glossary.md`
- [ ] 做了難以逆轉的技術決定 → 新增 ADR
- [ ] 使用者可見的變更 → 更新 `CHANGELOG.md`（非工程師看得懂的話）
- [ ] 改了本機環境設定 → 更新 `local-setup.md` 並更新驗證日期
- [ ] 以上皆不適用
```

### ISSUE_TEMPLATE/bug_report.yml

用 YAML form 而非 markdown template，因為它能**強制必填**：

```yaml
name: Bug 回報
description: 回報一個問題
labels: [bug, needs-triage]
body:
  - type: textarea
    id: what-happened
    attributes:
      label: 發生什麼事
      description: 也請說明你預期會發生什麼
    validations:
      required: true

  - type: textarea
    id: reproduce
    attributes:
      label: 重現步驟
      placeholder: |
        1. 前往 ...
        2. 點擊 ...
        3. 看到錯誤 ...
    validations:
      required: true

  - type: dropdown
    id: environment
    attributes:
      label: 環境
      options: [production, staging, local]
    validations:
      required: true

  - type: input
    id: order-id
    attributes:
      label: 相關訂單編號（若有）
      description: 方便我們查 log
```

### ISSUE_TEMPLATE/config.yml

```yaml
blank_issues_enabled: false
contact_links:
  - name: 💬 一般討論
    url: https://github.com/myorg/myrepo/discussions
    about: 問問題、討論想法請到 Discussions
  - name: 🔒 資安問題
    url: https://github.com/myorg/myrepo/security/advisories/new
    about: 請不要公開回報資安問題
```

---

## 10. Ruleset 收緊

```
Target: main

✓ Require pull request before merging
    - Required approvals: 1
    - Dismiss stale approvals on new commits    ← 重要
    - Require review from Code Owners
✓ Require status checks to pass
    - Require branches to be up to date
    - 勾選：lint, test, build
✓ Require conversation resolution               ← 很有用
✓ Block force pushes
```

### 兩個特別有用的選項

**Dismiss stale approvals on new commits**
避免「approve 之後又推了一堆東西」的漏洞。

**Require conversation resolution**
所有 review comment 必須被 resolve 才能合併。
這一個選項消滅了「comment 被忽略」的問題，效果出乎意料地好。

---

## 11. Environments 與部署保護

Settings → Environments。這比把 secrets 全放在 repo level 安全得多。

```
staging:
  Deployment branches: main, develop
  Secrets: STAGING_DATABASE_URL, STAGING_API_KEY

production:
  ✓ Required reviewers: @tech-lead, @sre-team
  ✓ Wait timer: 5 minutes          ← 給你反悔的時間
  ✓ Deployment branches: main only
  Secrets: PROD_DATABASE_URL, PROD_API_KEY
```

好處：

1. Secrets 隔離——production 的金鑰不會被 PR 的 workflow 讀到
2. 部署有審批紀錄，稽核時拿得出來
3. Wait timer 讓你有時間發現「我按錯了」

### 搭配 OIDC（推薦）

不要把雲端的長期金鑰放進 secrets，改用 OIDC：

```yaml
permissions:
  id-token: write
  contents: read

steps:
  - uses: aws-actions/configure-aws-credentials@v4
    with:
      role-to-assume: arn:aws:iam::123456789:role/github-deploy
      aws-region: ap-northeast-1
```

沒有長期金鑰可以外洩，這是目前的最佳實務。

---

## 12. CI 分工與安全掃描

### 分 job 並行

```yaml
jobs:
  lint:
    runs-on: ubuntu-latest
    steps: [...]          # ~30 秒

  test:
    runs-on: ubuntu-latest
    services:
      postgres:
        image: postgres:16
        env: { POSTGRES_PASSWORD: test }
        options: >-
          --health-cmd pg_isready --health-interval 10s
    steps: [...]          # ~2 分鐘

  build:
    runs-on: ubuntu-latest
    steps: [...]

  security:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
        with: { fetch-depth: 0 }
      - uses: gitleaks/gitleaks-action@v2
      - uses: actions/dependency-review-action@v4
```

### 開啟這幾個免費功能

Settings → Code security：

| 功能 | 說明 | 優先度 |
|---|---|---|
| **Secret scanning** | 掃描已提交的密鑰 | 高 |
| **Push protection** | **直接擋住含密鑰的 push** | **最高** |
| Dependabot alerts | 依賴漏洞通知 | 高 |
| Dependabot security updates | 自動開修補 PR | 高 |
| CodeQL | 靜態安全分析（公開 repo 免費，私有需 GHAS） | 中 |
| Private vulnerability reporting | 讓外部研究者私下回報 | 公開 repo 建議開 |

**Push protection 是單一 CP 值最高的設定**——
它在密鑰進入歷史之前就擋下來，省掉「輪替金鑰 + 清理歷史」的災難。

---

## 13. 自動標籤與 CODEOWNERS

### CODEOWNERS

```
# .github/CODEOWNERS
# 最後匹配的規則優先

*                       @myorg/backend-team

/src/domain/            @tech-lead
/prisma/                @tech-lead @dba
/.github/workflows/     @myorg/platform-team

/docs/00-overview/      @product-owner @tech-lead
/docs/05-decisions/     @tech-lead @architect
/docs/04-operations/    @myorg/sre-team
```

搭配 ruleset 的 `Require review from Code Owners`，
就能確保關鍵路徑一定被對的人看過。

### 自動標籤

```yaml
# .github/labeler.yml
documentation:
  - changed-files:
    - any-glob-to-any-file: ['docs/**', '**/*.md']

database:
  - changed-files:
    - any-glob-to-any-file: ['prisma/**', 'migrations/**']

ci:
  - changed-files:
    - any-glob-to-any-file: ['.github/**']

frontend:
  - changed-files:
    - any-glob-to-any-file: ['src/web/**']
```

```yaml
# .github/workflows/labeler.yml
name: Labeler
on: [pull_request_target]
permissions:
  contents: read
  pull-requests: write
jobs:
  label:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/labeler@v5
```

好處：release notes 分類自動化，PR 一眼看出影響範圍。

---

# 第三部：大專案（16+ 人）

重點從 repo 移到 **organization**。

## 14. Org 層級的 .github repo

在 org 下建一個名為 `.github` 的 repo，
裡面的東西會成為**所有 repo 的預設值**（repo 自己有的話優先）。

```
myorg/.github/                    ← 這個 repo 名字就叫 .github
├── profile/
│   └── README.md                 # org 首頁（公開 org 才顯示）
├── CODE_OF_CONDUCT.md
├── CONTRIBUTING.md
├── SECURITY.md
├── SUPPORT.md
├── PULL_REQUEST_TEMPLATE.md      # 所有 repo 繼承
├── ISSUE_TEMPLATE/
│   ├── bug_report.yml
│   ├── feature_request.yml
│   └── config.yml
└── workflow-templates/           # 新 repo 可一鍵套用
    ├── node-ci.yml
    ├── node-ci.properties.json
    ├── python-ci.yml
    └── python-ci.properties.json
```

`workflow-templates/*.properties.json` 讓 workflow 出現在
新 repo 的 Actions 建議清單裡：

```json
{
  "name": "Node.js CI（公司標準）",
  "description": "lint + typecheck + test + 安全掃描",
  "iconName": "nodejs",
  "categories": ["Node", "CI"],
  "filePatterns": ["package.json$"]
}
```

---

## 15. Reusable Workflows

避免 50 份 `ci.yml` 各自演化。

```yaml
# myorg/shared-workflows/.github/workflows/node-ci.yml
name: Node CI

on:
  workflow_call:
    inputs:
      node-version:
        type: string
        default: '20'
      run-e2e:
        type: boolean
        default: false
    secrets:
      NPM_TOKEN:
        required: false

jobs:
  check:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: ${{ inputs.node-version }}
          cache: 'npm'
      - run: npm ci
      - run: npm run lint
      - run: npm run typecheck
      - run: npm test
      - if: inputs.run-e2e
        run: npm run test:e2e

  security:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: gitleaks/gitleaks-action@v2
```

各 repo 只要：

```yaml
# 各服務的 .github/workflows/ci.yml
name: CI
on: [push, pull_request]

jobs:
  ci:
    uses: myorg/shared-workflows/.github/workflows/node-ci.yml@v1
    with:
      node-version: '20'
      run-e2e: true
    secrets: inherit
```

**改一次，全公司生效。** 記得用 tag（`@v1`）而非 `@main`，
這樣共用 workflow 的變更不會意外炸掉所有 repo。

---

## 16. Organization Rulesets

Org 層級強制所有 repo 必須遵守某些規則，個別 repo 不能關掉。

Organization Settings → Repository → Rulesets：

```
Name: 全公司基本規範
Target repositories: All repositories（或用 property 篩選）
Target branches: Default branch

✓ Require pull request (approvals: 1)
✓ Block force pushes
✓ Require signed commits           ← 大組織建議開
✓ Restrict deletions

Required workflows:
  - myorg/shared-workflows/.github/workflows/security-baseline.yml@v1
```

### Repository Properties

先給 repo 打標籤，再用標籤套規則：

```
Properties:
  tier: critical | standard | experimental
  language: node | python | go
  data-classification: pii | internal | public
```

然後 ruleset 可以針對 `tier: critical` 套更嚴的規則
（2 approvals、必須 signed commits、必須跑滲透測試 workflow）。

---

## 17. Template Repository

前面 Part 2 講的「所有服務用同一套骨架（golden path）」，
在 GitHub 上就是 template repo。

```
myorg/service-template/           ← Settings 勾選 "Template repository"
├── .devcontainer/
├── .github/
│   ├── workflows/ci.yml          # 直接 uses: shared-workflows
│   └── CODEOWNERS
├── docs/                         ← 完整的文件骨架
│   ├── 00-overview/
│   │   ├── overview.md           # 含 TODO 提示
│   │   └── glossary.md
│   ├── 01-architecture/
│   ├── 02-development/
│   ├── 04-operations/
│   │   └── runbook.md
│   └── 05-decisions/adr/
│       ├── README.md
│       └── template.md
├── src/
├── catalog-info.yaml             ← service catalog 用
├── CLAUDE.md
├── Makefile
└── README.md
```

**每個文件檔案都預先放好，內容是提示而非空白：**

```markdown
<!-- docs/00-overview/overview.md -->
# {服務名稱} — 系統總覽

**維護者**：@TODO ｜ **最後更新**：TODO

## 一句話

<!-- TODO: 用一句非工程師看得懂的話說明這個服務做什麼 -->

## 它「不」做什麼

<!-- TODO: 這一段比上面那段更重要，務必填寫 -->
```

空的 TODO 比空的檔案有用得多，因為它告訴人「這裡該寫什麼」。

---

## 18. 供應鏈安全

| 措施 | 做法 | 為什麼 |
|---|---|---|
| **Pin actions to SHA** | `uses: actions/checkout@a1b2c3...` | tag 可以被移動，SHA 不行。防供應鏈攻擊 |
| **限制 Actions 來源** | Org Settings → Actions → Allow select actions | 只允許 GitHub 官方 + 白名單 |
| **最小權限** | 每個 workflow 明示 `permissions:` | 預設是寬鬆的 |
| **Artifact Attestation** | `actions/attest-build-provenance` | 證明 build 出自哪個 commit、哪條 workflow |
| **SBOM** | 依賴清單，稽核用 | 供應鏈事件時能快速判斷是否受影響 |
| **OIDC 取代長期金鑰** | 見第 11 節 | 沒有金鑰可以外洩 |

### 最小權限範例

```yaml
# 檔案層級設為唯讀，個別 job 再開需要的
permissions:
  contents: read

jobs:
  release:
    permissions:
      contents: write        # 只有這個 job 需要寫
      id-token: write        # OIDC
```

### Pin 到 SHA 的維護

手動 pin 很痛苦，用 Dependabot 自動更新（它會連 SHA 一起更）：

```yaml
- package-ecosystem: "github-actions"
  directory: "/"
  schedule: { interval: "weekly" }
```

---

## 19. Service Catalog

GitHub 本身沒有內建，但可以組合出來：

### 方法一：每個 repo 一份 catalog-info.yaml

用 Backstage 格式（就算沒導入 Backstage，格式也值得沿用）：

```yaml
# catalog-info.yaml
apiVersion: backstage.io/v1alpha1
kind: Component
metadata:
  name: order-service
  description: 訂單生命週期管理
  annotations:
    github.com/project-slug: myorg/order-service
    pagerduty.com/service-id: PXXXXX
  tags: [nodejs, commerce, tier-critical]
  links:
    - url: https://grafana.internal/d/orders
      title: 監控看板
    - url: https://myorg.slack.com/channels/commerce-eng
      title: Slack 頻道
spec:
  type: service
  lifecycle: production
  owner: team-commerce
  dependsOn:
    - component:catalog-service
    - component:inventory-service
    - resource:orders-postgres
```

### 方法二：用 GitHub topics + 聚合腳本

比較輕量：每個 repo 打 topics（`team-commerce`、`tier-critical`），
寫一支腳本用 GitHub API 撈出來，生成一份 markdown 索引。

### 一定要記錄的欄位

| 欄位 | 為什麼 |
|---|---|
| 擁有團隊 + Slack 頻道 | 「這是誰維護的」在大組織是天天要問的問題 |
| 值班資訊 | 半夜出事找誰 |
| SLO | 判斷嚴重度 |
| 上下游依賴 | 影響範圍分析 |
| 資料敏感度 | 資安與法遵 |
| Lifecycle | production / deprecated / experimental |

---

# 第四部：對照與檢查

## 20. 規模對照表

| | 小（1–3 人） | 中（4–15 人） | 大（16+ 人） |
|---|---|---|---|
| **Ruleset** | status check + no force push | + PR 1 approval + CODEOWNERS + conversation resolution | Org-level ruleset 強制 + signed commits |
| **CI** | 單 job，< 3 分鐘 | 分 job 並行 + 安全掃描 | Reusable workflow |
| **CODEOWNERS** | 不用 | 需要 | 強制，到 team 層級 |
| **PR template** | 不用 | 需要（含文件檢查） | Org `.github` 統一 |
| **Issue template** | 不用 | YAML form | Org 統一 |
| **Environments** | 不用 | prod 加審批 | 多環境 + OIDC + tier 分級 |
| **Dependabot** | grouped + patch auto-merge | 同左 + 安全更新優先 | 集中式依賴政策 |
| **Secret scanning** | **開 push protection** | 同左 | + CodeQL + SBOM + attestation |
| **Actions 來源** | 不限 | 不限 | 白名單 + pin SHA |
| **新 repo 怎麼開** | 手動 | 手動 + checklist | Template repo |
| **文件** | README + DECISIONS | 7 份 | 完整 + catalog + portal |

---

## 21. 新 Repo 檢查清單

### 小專案（15 分鐘）

```markdown
- [ ] Settings → 只留 squash merge
- [ ] Settings → Automatically delete head branches
- [ ] Settings → Allow auto-merge
- [ ] Settings → 關掉不用的 Wiki / Projects
- [ ] Code security → Secret scanning + Push protection
- [ ] Code security → Dependabot alerts + security updates
- [ ] Ruleset：status check + block force push
- [ ] 建立 .editorconfig
- [ ] 建立 .nvmrc（或對應版本檔）
- [ ] 建立 Makefile（make check == CI）
- [ ] 建立 .env.example（每個變數註明用途與取得方式）
- [ ] 建立 ci.yml（含 concurrency + cache）
- [ ] 建立 dependabot.yml（含 grouping）
- [ ] 建立 README.md（含「5 分鐘跑起來」）
- [ ] 建立 DECISIONS.md
- [ ] 建立 CLAUDE.md
- [ ] 選擇 LICENSE
```

### 中專案（追加）

```markdown
- [ ] CODEOWNERS
- [ ] pull_request_template.md（含文件檢查清單）
- [ ] ISSUE_TEMPLATE/（YAML form + config.yml）
- [ ] Ruleset 收緊（PR + approvals + conversation resolution）
- [ ] Environments（staging / production + 審批）
- [ ] OIDC 取代雲端長期金鑰
- [ ] CI 分 job + 安全掃描
- [ ] labeler.yml 自動標籤
- [ ] release.yml 自動 changelog
- [ ] docs/ 七份核心文件
```

### 大專案（追加）

```markdown
- [ ] 從 template repo 建立
- [ ] catalog-info.yaml 填寫完整
- [ ] 套用 org reusable workflow
- [ ] Repository properties（tier / data-classification）
- [ ] 註冊到 service catalog
- [ ] PagerDuty / 值班設定
- [ ] SLO 定義與監控
- [ ] 上下游依賴登記
```

---

## 22. 常見錯誤

| 錯誤 | 後果 | 修法 |
|---|---|---|
| CI 太慢（> 10 分鐘） | 大家開始跳過、強制合併 | 加 cache、分 job 並行、把 e2e 移到 nightly |
| Dependabot 沒設 grouping | 每週 15 個 PR，全部忽略 | 設 groups + limit + auto-merge patch |
| Ruleset 開太嚴 | 大家學會用 bypass，規則形同虛設 | 從寬到嚴逐步收緊 |
| Secrets 放在 repo level | PR 的 workflow 可能讀到 production 金鑰 | 移到 Environment secrets |
| Actions 用 `@main` | 上游一改就炸，且有供應鏈風險 | pin 到 tag 或 SHA |
| 本機與 CI 檢查不同 | 「本機明明過了」 | `make check` == CI |
| 開了 Wiki 又用 docs/ | 兩個真相來源，都不準 | 選一個，關掉另一個 |
| 沒開 push protection | 密鑰進入歷史，要輪替 + 清理 | 現在就去開 |
| 大量使用 `workflow_dispatch` 手動觸發 | 沒有紀錄、容易忘 | 自動化觸發條件 |

---

## 如果只做三件事

不管什麼規模，這三個 CP 值最高：

| # | 做什麼 | 為什麼 |
|---|---|---|
| 1 | **Secret scanning 的 Push Protection** | 一個開關，防止最貴的意外 |
| 2 | **Automatically delete head branches** | 一個勾選，長期整潔 |
| 3 | **`make check` == CI 跑的東西** | 消滅「本機過了 CI 卻紅」 |

---

## 附錄：三份文件的關係

| 文件 | 回答什麼 |
|---|---|
| **Part 1**：專案文件架構完整指南 | 該寫哪些文件、長什麼樣（含 7 份可複製範本） |
| **Part 2**：專案文件策略 | 依規模怎麼調整、什麼時候不該寫、實戰情境 |
| **Part 3**：GitHub 起手式（本文件） | 在 GitHub 上怎麼設定、讓規則自動執行 |

三者的共同主張：

> **能用設定強制的，不要用文件約定。
> 能用文件說明的，不要用口頭傳達。
> 能用程式表達的，不要寫文件。**
