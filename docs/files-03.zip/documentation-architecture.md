# 專案文件架構完整指南

> 目標讀者：想在專案中導入一套「維護得動」的文件體系的技術主管 / Tech Lead
> 適用情境：搭配 Claude Code 使用，讓文件與程式同步演進

---

## 目錄

1. [設計原則](#1-設計原則)
2. [讀者矩陣](#2-讀者矩陣)
3. [完整目錄結構](#3-完整目錄結構)
4. [文件規格與範本](#4-文件規格與範本)
5. [維護機制](#5-維護機制)
6. [CLAUDE.md 設定](#6-claudemd-設定)
7. [導入路線圖](#7-導入路線圖)
8. [文件健康度檢查](#8-文件健康度檢查)

---

## 1. 設計原則

### 原則一：一份文件只服務一種讀者

最常見的失敗是「一份 README 想同時給老闆、PM、新人、SRE 看」，結果四種人都覺得沒講到自己要的。
寧可拆成四份短的，也不要一份長的。

### 原則二：文件分「會過期」與「不會過期」

| 類型 | 特性 | 策略 |
|---|---|---|
| **不會過期**（Why 類） | ADR、Glossary、設計原則 | 用「追加」而非「修改」，舊決策標記 `Superseded` 而不是刪掉 |
| **會過期**（What 類） | API 規格、環境變數、目錄結構 | 盡量自動生成，或綁進 CI 檢查 |
| **一定會過期**（How 類） | 操作步驟、截圖 | 標註 `最後驗證日期`，超過 90 天顯示警告 |

### 原則三：文件與程式同一個 PR

不進 code review 的文件，三個月後一定是錯的。

### 原則四：可執行 > 可閱讀

- 能寫成腳本的，不要寫成「請依序執行以下步驟」
- 能寫成測試的，不要寫成「本模組的行為規格」
- 能寫成型別的，不要寫成「此欄位可能為 null」

### 原則五：少而準

5 份被信任的文件 > 30 份沒人敢看的文件。
每季做一次「刪除審查」：這份文件過去三個月有人看過嗎？沒有就刪。

---

## 2. 讀者矩陣

在寫任何一份文件前，先確認它在這張表的哪一格。

| 讀者 | 他真正的問題 | 對應文件 | 不該給他看 |
|---|---|---|---|
| **高層 / 老闆** | 這東西值多少錢？風險在哪？ | `overview.md` 的前半頁 | 任何架構圖 |
| **PM / 業務 / 營運** | 這功能能不能做？做多久？出事影響誰？ | `overview.md`、`glossary.md`、`user-journey.md`、`faq.md` | 目錄結構、程式碼 |
| **設計師** | 系統有哪些狀態？錯誤長什麼樣？ | `user-journey.md`、`state-machine.md` | 資料庫 schema |
| **新手工程師（第 1 天）** | 我怎麼把它跑起來？ | `README.md`、`docs/local-setup.md` | ADR（太早） |
| **新手工程師（第 1 週）** | 我要改的東西在哪？為什麼長這樣？ | `architecture.md`、`walkthrough.md`、`adr/` | Runbook |
| **資深工程師 / 新加入的資深** | 有哪些坑？當初為什麼不用 X？ | `adr/`、`architecture.md` 的 Trade-offs 段 | README |
| **QA** | 邊界條件是什麼？怎麼驗證？ | `api.md`、測試檔、`state-machine.md` | ADR |
| **值班 / SRE** | 現在壞了，怎麼辦？ | `runbook.md`、`alerts.md` | 其他全部 |
| **外部串接夥伴** | 我怎麼呼叫你們？ | `openapi.yaml`、`integration-guide.md` | 內部架構 |
| **資安 / 稽核** | 資料流到哪？誰有權限？ | `data-flow.md`、`security.md` | — |

---

## 3. 完整目錄結構

```
專案根目錄/
│
├── README.md                    ★ 唯一入口，導向其他所有文件
├── CONTRIBUTING.md              ★ 開發規範
├── CHANGELOG.md                 ★ 版本紀錄（人話版）
├── CLAUDE.md                    ★ 給 Claude Code 的專案規則
├── .env.example                 ★ 環境變數範本（含註解）
│
├── docs/
│   │
│   ├── 00-overview/             【非工程師區】
│   │   ├── overview.md          一頁紙：這是什麼
│   │   ├── glossary.md          名詞表 ★★★ 最被低估
│   │   ├── user-journey.md      使用者旅程
│   │   ├── faq.md               常見問題（跨部門）
│   │   └── roadmap.md           路線圖（選配）
│   │
│   ├── 01-architecture/         【工程師區：系統面】
│   │   ├── architecture.md      架構總覽
│   │   ├── context-diagram.md   C4 L1：系統與外界
│   │   ├── container-diagram.md C4 L2：內部服務
│   │   ├── data-model.md        資料模型 + ER 圖
│   │   ├── data-flow.md         資料流（含 PII 標註）
│   │   ├── state-machine.md     核心物件的狀態機
│   │   └── integrations.md      外部系統依賴清單
│   │
│   ├── 02-development/          【工程師區：動手面】
│   │   ├── local-setup.md       本機環境建置
│   │   ├── walkthrough.md       主流程追碼 ★★★ 新人最有感
│   │   ├── code-map.md          目錄結構說明
│   │   ├── testing.md           測試策略與執行
│   │   ├── conventions.md       命名 / 錯誤處理 / log 規範
│   │   └── troubleshooting.md   開發時常見錯誤
│   │
│   ├── 03-api/                  【契約區】
│   │   ├── openapi.yaml         自動生成，勿手改
│   │   ├── api-guide.md         人寫的補充說明
│   │   ├── events.md            訊息 / 事件契約
│   │   └── integration-guide.md 給外部夥伴
│   │
│   ├── 04-operations/           【運維區】
│   │   ├── runbook.md           出事怎麼辦 ★★
│   │   ├── alerts.md            告警清單與意義
│   │   ├── deployment.md        部署流程與回滾
│   │   ├── monitoring.md        看板與指標定義
│   │   └── oncall.md            值班交接
│   │
│   ├── 05-decisions/            【決策區】
│   │   └── adr/
│   │       ├── README.md        ADR 索引與使用說明
│   │       ├── template.md
│   │       ├── 0001-use-postgresql.md
│   │       ├── 0002-monolith-first.md
│   │       └── 0003-event-sourcing-for-orders.md
│   │
│   ├── 06-security/             【資安區】
│   │   ├── security.md          威脅模型與防護
│   │   ├── permissions.md       角色與權限矩陣
│   │   └── data-retention.md    資料保存與刪除政策
│   │
│   └── assets/                  圖片、截圖、原始檔
│       └── diagrams/
```

### 精簡版（小專案 / 3 人以下團隊）

不要一開始就建 30 個檔案。小專案用這個就夠：

```
README.md
CLAUDE.md
docs/
├── overview.md      # 非工程師看的
├── glossary.md      # 名詞表
├── architecture.md  # 架構 + 目錄結構 + 資料模型，合成一份
├── walkthrough.md   # 一條主流程
├── runbook.md       # 出事怎麼辦
└── adr/
```

---

## 4. 文件規格與範本

以下每份文件包含：**目的 / 讀者 / 長度上限 / 更新觸發條件 / 範本**

長度上限很重要——它強迫你把次要內容移到別的檔案，而不是無限膨脹。

---

### 4.1 README.md

- **目的**：讓任何人在 30 秒內知道「這是什麼」，5 分鐘內跑起來
- **讀者**：所有人（第一次接觸）
- **長度上限**：150 行
- **更新觸發**：安裝步驟改變、主要依賴升級、新增子服務

```markdown
# 訂單服務 Order Service

一句話：處理電商平台從下單到出貨的訂單生命週期管理。

[![CI](badge)](link) [![Coverage](badge)](link)

## 這是什麼

負責接收前台訂單、驗證庫存、鎖定金流、產生出貨單。
**不負責**：商品目錄、會員資料、實際金流扣款（由 Payment Service 處理）。

## 快速開始（5 分鐘）

前置需求：Docker 20+、Node.js 20+

    git clone git@github.com:company/order-service.git
    cd order-service
    cp .env.example .env
    make dev

**怎麼確認成功了？**
打開 http://localhost:3000/health，看到 `{"status":"ok"}` 就對了。
再執行 `make smoke-test`，應該全綠。

跑不起來？→ [docs/02-development/troubleshooting.md](docs/02-development/troubleshooting.md)

## 我該看哪份文件

| 你是誰 | 從這裡開始 |
|---|---|
| PM / 營運 | [系統總覽](docs/00-overview/overview.md) → [名詞表](docs/00-overview/glossary.md) |
| 新加入的工程師 | [本機環境](docs/02-development/local-setup.md) → [主流程追碼](docs/02-development/walkthrough.md) |
| 要改架構的人 | [架構總覽](docs/01-architecture/architecture.md) → [ADR](docs/05-decisions/adr/) |
| 值班中，出事了 | [Runbook](docs/04-operations/runbook.md) |
| 外部串接 | [API 指南](docs/03-api/integration-guide.md) |

## 常用指令

| 指令 | 用途 |
|---|---|
| `make dev` | 啟動開發環境（含 DB、Redis） |
| `make test` | 跑全部測試 |
| `make test-watch` | 監看模式 |
| `make lint` | 檢查格式 |
| `make db-reset` | 重建資料庫並灌測試資料 |

## 聯絡

- 負責團隊：Commerce Team（#commerce-eng）
- 值班：PagerDuty `order-service`
- 產品負責人：@someone
```

---

### 4.2 docs/00-overview/overview.md（一頁紙）

- **目的**：讓非技術同事理解系統的價值與邊界
- **讀者**：PM、業務、營運、高層
- **長度上限**：1 頁（約 80 行），**不得出現任何程式碼或類別名稱**
- **更新觸發**：系統範圍改變、新增重大功能、下線功能

```markdown
# 訂單服務 — 系統總覽

**最後更新**：2026-08-21 ｜ **維護者**：@tech-lead

## 一句話

訂單服務負責記錄「客人買了什麼」，並確保這筆訂單不會被重複扣款、不會超賣。

## 它解決什麼問題

在拆出這個服務之前，訂單邏輯散落在前台網站和後台管理系統，導致：
- 促銷檔期常發生超賣，平均每檔要人工處理 30～50 筆
- 前後台訂單狀態不一致，客服無法回答「我的貨到底出了沒」

## 它做什麼

1. **接單**：接收前台送來的訂單，檢查金額與商品是否合法
2. **鎖庫存**：向庫存服務預扣，15 分鐘內未付款自動釋放
3. **狀態管理**：維護訂單從「待付款」到「已完成」的所有狀態變化
4. **通知**：狀態改變時通知客服系統、物流系統、會員系統

## 它「不」做什麼（很重要）

| 這件事 | 由誰負責 |
|---|---|
| 實際刷卡、扣款 | Payment Service |
| 商品價格、上下架 | Catalog Service |
| 會員資料、點數 | Member Service |
| 實體出貨、貨運追蹤 | 物流系統（外部廠商 XYZ） |
| 發票開立 | 財會系統 |

**所以**：如果客訴是「刷卡失敗」，不是訂單服務的問題，找 Payment Team。

## 誰在用它

| 使用者 | 怎麼用 |
|---|---|
| 消費者 | 間接使用（透過前台網站 / App 下單） |
| 客服人員 | 透過客服後台查詢、取消、改地址 |
| 倉儲人員 | 透過倉儲系統接收出貨單 |
| 財會 | 每日對帳報表 |

## 系統關係圖

（此處放 C4 Level 1 圖：中間一個「訂單服務」，外圍是使用者與外部系統，
不畫任何內部細節）

## 關鍵數字

| 指標 | 目前 |
|---|---|
| 日均訂單量 | 約 12,000 筆 |
| 尖峰（雙11） | 每分鐘 800 筆 |
| 可用性目標 | 99.9%（每月容許停機約 43 分鐘） |
| 訂單建立回應時間 | 95% 在 300ms 內 |

## 出事的話會怎樣

| 故障 | 業務影響 | 應變 |
|---|---|---|
| 服務完全停擺 | 前台無法下單，直接損失營收 | 值班 15 分鐘內響應 |
| 庫存鎖定失敗 | 可能超賣，需事後人工道歉退款 | 自動切換為保守模式（拒單） |
| 通知延遲 | 客服看到的狀態落後，可能誤答客戶 | 通常 10 分鐘內自動追上 |

## 目前已知限制

- 一張訂單最多 100 個品項（技術限制，尚未有需求要放寬）
- 不支援跨幣別（只支援 TWD）
- 訂單建立後無法修改品項，只能取消重下
```

---

### 4.3 docs/00-overview/glossary.md（名詞表）★★★

- **目的**：消除跨部門溝通中最大的斷點——同一個詞不同意思
- **讀者**：全員
- **長度上限**：無上限，但要維持字母 / 筆劃排序
- **更新觸發**：**任何 PR 引入新的領域名詞、或改變既有名詞的定義**

這是投資報酬率最高的一份文件，卻幾乎沒有團隊在寫。

```markdown
# 名詞表 Glossary

> 規則：如果一個詞在會議中被誤解過一次，就該進這張表。

## 使用方式

- 程式碼中的類別 / 變數命名，必須採用本表的「英文代號」
- 與外部溝通時，使用「業務用語」欄
- 發現定義不一致 → 開 issue，不要各自解讀

---

### 訂單 Order

- **英文代號**：`Order`
- **定義**：消費者一次結帳行為所產生的紀錄，包含 1～N 個訂單品項。
- **注意**：
  - 業務口中的「一單」有時指「一張訂單」，有時指「一個包裹」。系統中**一張訂單可能拆成多個包裹**。
  - 不要與「單據」混用，「單據」在財會系統中指發票。
- **相關**：訂單品項、出貨單

### 訂單品項 Order Item

- **英文代號**：`OrderItem`
- **定義**：一張訂單中的一列，代表「某商品 × 數量」。
- **注意**：同一商品在同一訂單中只會有一列（數量累加），不會出現兩列。

### 出貨單 Shipment

- **英文代號**：`Shipment`
- **定義**：一次實體出貨，對應一個物流追蹤號碼。
- **注意**：一張訂單可對應多張出貨單（分批出貨）。**這是很多人搞錯的地方。**

### 預扣庫存 Stock Reservation

- **英文代號**：`StockReservation`
- **業務用語**：「鎖庫存」
- **定義**：訂單建立時暫時保留庫存，有效期 15 分鐘。
- **注意**：預扣 ≠ 扣除。真正扣庫存是在付款成功時。庫存報表上兩者是不同欄位。

### 取消 Cancel vs 退貨 Return vs 退款 Refund

**這三個最常被混用，務必區分：**

| 詞 | 英文代號 | 發生時機 | 有無物流 |
|---|---|---|---|
| 取消 | `Cancel` | 出貨前 | 無 |
| 退貨 | `Return` | 出貨後，商品寄回 | 有（逆物流） |
| 退款 | `Refund` | 金流動作，可能因取消或退貨而觸發 | 無關 |

一次取消會觸發一次退款；一次退貨也會觸發一次退款。但退款不一定伴隨退貨。

---

## 縮寫對照

| 縮寫 | 全稱 | 說明 |
|---|---|---|
| SKU | Stock Keeping Unit | 最小庫存單位，含顏色尺寸 |
| SPU | Standard Product Unit | 商品款式，一個 SPU 含多個 SKU |
| GMV | Gross Merchandise Value | 成交總額，含尚未付款的訂單 |
| AOV | Average Order Value | 客單價 |

## 已淘汰的名詞

| 舊詞 | 現在叫 | 淘汰時間 | 原因 |
|---|---|---|---|
| 交易單 | 訂單 Order | 2025-03 | 與財會的「交易」概念衝突 |
| 鎖單 | 預扣庫存 | 2025-06 | 語意不清 |
```

---

### 4.4 docs/00-overview/user-journey.md

- **目的**：用使用者視角描述系統行為
- **讀者**：PM、設計師、QA、客服
- **長度上限**：每條旅程 1 頁
- **更新觸發**：使用者流程改變

```markdown
# 使用者旅程

## 旅程一：消費者下單（Happy Path）

| 步驟 | 使用者看到 | 系統在做什麼 | 耗時 |
|---|---|---|---|
| 1 | 點「結帳」 | 建立訂單、驗證商品與價格 | < 0.3s |
| 2 | 看到「處理中」 | 向庫存服務預扣 | < 0.5s |
| 3 | 跳轉金流頁 | 訂單狀態 = 待付款，開始 15 分計時 | — |
| 4 | 輸入卡號、送出 | （由 Payment Service 處理） | 3～10s |
| 5 | 看到「訂單成立」 | 收到付款成功事件 → 狀態 = 已付款 → 真正扣庫存 → 通知倉儲 | < 1s |
| 6 | 收到 Email | 通知服務寄送確認信 | 1～3 分鐘 |

## 旅程二：15 分鐘內未付款

| 步驟 | 使用者看到 | 系統在做什麼 |
|---|---|---|
| 1 | 停留在金流頁太久 | 背景計時中 |
| 2 | 送出付款，看到「訂單已逾時」 | 預扣已釋放，訂單狀態 = 已逾時 |
| 3 | 回到購物車重新下單 | 建立**新**訂單（不會沿用舊訂單） |

**客服常見問題**：客戶說「我明明有付款」→ 請查 Payment Service 是否有成功紀錄。
若付款成功但訂單已逾時，屬於例外狀況，走人工補單流程（見 runbook）。

## 訂單狀態一覽（給客服）

| 客戶端顯示 | 內部狀態 | 意思 | 可否取消 |
|---|---|---|---|
| 待付款 | `PENDING_PAYMENT` | 已下單未付款 | 可 |
| 處理中 | `PAID` | 已付款，倉儲準備中 | 可（需審核） |
| 已出貨 | `SHIPPED` | 交給物流 | 不可，走退貨 |
| 已完成 | `COMPLETED` | 簽收後 7 天 | 不可 |
| 已取消 | `CANCELLED` | — | — |
| 已逾時 | `EXPIRED` | 15 分未付款 | — |
```

---

### 4.5 docs/01-architecture/architecture.md

- **目的**：讓工程師建立系統的心智模型
- **讀者**：工程師（第 1 週起）
- **長度上限**：300 行；超過就拆到子文件
- **更新觸發**：新增 / 移除服務、改變資料流、引入新的核心抽象

```markdown
# 架構總覽

**最後更新**：2026-08-21 ｜ **維護者**：@tech-lead

## TL;DR

單體 Node.js 服務 + PostgreSQL + Redis，透過 Kafka 與其他服務非同步溝通。
訂單狀態變更採用狀態機模式，所有狀態轉移集中在 `src/domain/order/state-machine.ts`。

刻意不拆微服務，原因見 [ADR-0002](../05-decisions/adr/0002-monolith-first.md)。

## 系統脈絡（C4 Level 1）

```mermaid
graph TB
    User[消費者] --> Web[前台網站]
    CS[客服人員] --> Admin[客服後台]
    Web --> OS[訂單服務]
    Admin --> OS
    OS --> Pay[Payment Service]
    OS --> Inv[Inventory Service]
    OS --> Cat[Catalog Service]
    OS --> Kafka[(Kafka)]
    Kafka --> WMS[倉儲系統]
    Kafka --> Notify[通知服務]
```

## 內部結構（C4 Level 2）

```mermaid
graph TB
    subgraph 訂單服務
        API[HTTP API 層]
        APP[Application 層]
        DOM[Domain 層]
        INFRA[Infrastructure 層]
        WORKER[背景工作者]
    end
    API --> APP
    APP --> DOM
    APP --> INFRA
    WORKER --> APP
    INFRA --> DB[(PostgreSQL)]
    INFRA --> Cache[(Redis)]
    INFRA --> MQ[(Kafka)]
```

## 分層規則

| 層 | 職責 | 可以依賴 | 禁止 |
|---|---|---|---|
| `api/` | HTTP 路由、驗證輸入、序列化輸出 | application | 直接碰 DB |
| `application/` | 用例編排、交易邊界 | domain, infrastructure 介面 | 寫業務規則 |
| `domain/` | 業務規則、狀態機、實體 | 無（純函式） | **import 任何框架或 DB** |
| `infrastructure/` | DB、Kafka、外部 API 實作 | domain（實作其介面） | 被 domain 依賴 |

**檢查方式**：`make lint-arch`（使用 dependency-cruiser，違規會擋 CI）

## 核心抽象

### 1. Order Aggregate

`src/domain/order/order.ts` — 訂單是唯一的 aggregate root。
所有對訂單品項的修改都必須透過 Order 物件，不可直接操作 OrderItem。

### 2. 狀態機

`src/domain/order/state-machine.ts` — 定義所有合法的狀態轉移。
新增狀態時**只需要改這一個檔案**，其他地方會自動受型別保護。

### 3. Domain Events

狀態轉移會產生事件（`OrderPaid`、`OrderCancelled`…），
在交易 commit 後才發送到 Kafka（Transactional Outbox，見 ADR-0005）。

## 關鍵資料流

### 下單流程

1. `POST /orders` → `CreateOrderUseCase`
2. 開啟 DB 交易
3. 呼叫 Catalog 驗價（同步 HTTP，有 3 秒 timeout + 熔斷）
4. 呼叫 Inventory 預扣（同步 HTTP，冪等鍵 = orderId）
5. 寫入 orders + order_items + outbox 三張表
6. Commit
7. Outbox worker 每 500ms 掃描並發送 Kafka 事件

**為什麼不用分散式交易**：見 ADR-0004。我們接受「預扣成功但訂單寫入失敗」
的極少數情況，靠 15 分鐘自動釋放兜底。

## Trade-offs（給資深工程師）

| 我們選了 | 放棄了 | 原因 |
|---|---|---|
| 單體 | 微服務 | 團隊 6 人，拆了維運成本 > 收益（ADR-0002） |
| Outbox pattern | 直接發 Kafka | 保證不漏事件，代價是最多 500ms 延遲（ADR-0005） |
| 同步呼叫庫存 | 非同步預扣 | 使用者需要即時知道有沒有貨（ADR-0006） |
| PostgreSQL | MongoDB | 需要交易保證（ADR-0001） |

## 已知的技術債

| 項目 | 影響 | 追蹤 |
|---|---|---|
| `LegacyOrderAdapter` 為舊系統相容而存在 | 新人容易誤用 | #234，2026Q4 移除 |
| 訂單查詢未分頁，超過 1000 筆會慢 | 客服後台偶發 timeout | #189 |

## 延伸閱讀

- [資料模型](data-model.md)
- [狀態機細節](state-machine.md)
- [主流程追碼](../02-development/walkthrough.md)
```

---

### 4.6 docs/02-development/walkthrough.md ★★★

- **目的**：帶新人走完一條完整請求，建立「程式在哪、怎麼串」的直覺
- **讀者**：新手工程師（到職第 2～3 天）
- **長度上限**：一條主流程，約 200 行
- **更新觸發**：檔案路徑改變、流程步驟增減

**這份文件的投資報酬率通常大於所有行內註解的總和。**

```markdown
# 主流程追碼：一筆訂單的旅程

> 讀完這份，你應該能自己找到「要改哪個檔案」。
> 預計閱讀時間 30 分鐘。建議一邊開 IDE 一邊看。

## 準備

    make dev
    make db-reset

在 `src/application/order/create-order.use-case.ts:42` 下中斷點，
然後執行：

    curl -X POST localhost:3000/orders \
      -H 'Content-Type: application/json' \
      -d '{"userId":"u_001","items":[{"sku":"SKU-A","qty":2}]}'

---

## 第 1 站：HTTP 進入點

**檔案**：`src/api/routes/order.routes.ts:28`

    router.post('/orders', validate(CreateOrderSchema), orderController.create)

- `validate()` 是 middleware，用 zod 檢查輸入格式。schema 在 `src/api/schemas/order.schema.ts`
- **這裡只做格式驗證，不做業務驗證**。「這個商品能不能買」不在這層

**新人常犯的錯**：把業務規則寫進 schema。請不要。

---

## 第 2 站：Controller

**檔案**：`src/api/controllers/order.controller.ts:15`

    async create(req, res) {
      const command = toCreateOrderCommand(req.body, req.user)
      const result = await this.createOrderUseCase.execute(command)
      res.status(201).json(toOrderResponse(result))
    }

Controller 只做三件事：轉換輸入 → 呼叫 use case → 轉換輸出。
**如果你發現自己想在 controller 寫 if，多半是放錯地方了。**

---

## 第 3 站：Use Case（重點）

**檔案**：`src/application/order/create-order.use-case.ts:42`

這是整個流程的指揮中心。它負責「編排」，但不寫業務規則。

    async execute(cmd: CreateOrderCommand): Promise<Order> {
      return this.uow.transaction(async (tx) => {
        // 3-1 驗價
        const priced = await this.catalog.priceItems(cmd.items)

        // 3-2 建立 domain 物件（業務規則在這裡面）
        const order = Order.create({ userId: cmd.userId, items: priced })

        // 3-3 預扣庫存
        await this.inventory.reserve(order.id, order.items)

        // 3-4 存檔（同時寫 outbox）
        await this.orderRepo.save(order, tx)
        await this.outbox.publish(order.pullEvents(), tx)

        return order
      })
    }

**四個子站，逐一往下追：**

### 3-1 驗價 → `src/infrastructure/catalog/catalog.client.ts:30`

- 走 HTTP 呼叫 Catalog Service
- 有熔斷器（opossum），連續 5 次失敗會開路 30 秒
- **失敗會怎樣**：整筆交易 rollback，回 503。使用者看到「系統忙碌」

### 3-2 建立訂單 → `src/domain/order/order.ts:55`

**這裡是業務規則的家。** 打開看 `Order.create()`：

    static create(props): Order {
      if (props.items.length === 0) throw new EmptyOrderError()
      if (props.items.length > 100) throw new TooManyItemsError()
      const order = new Order({ ...props, status: 'PENDING_PAYMENT' })
      order.addEvent(new OrderCreatedEvent(order.id))
      return order
    }

注意：這個檔案**沒有 import 任何框架**。它是純 TypeScript。
所以它的測試跑起來只要 5ms，不需要 DB。
→ 看 `src/domain/order/order.test.ts`，這是你之後寫測試的範本。

### 3-3 預扣庫存 → `src/infrastructure/inventory/inventory.client.ts:44`

- 帶 `Idempotency-Key: {orderId}`，重送不會重複扣
- 失敗會怎樣：rollback，回 409「庫存不足」

### 3-4 存檔 → `src/infrastructure/persistence/order.repository.ts:80`

- 用 Prisma。schema 在 `prisma/schema.prisma`
- Domain 物件 → DB row 的轉換在 `order.mapper.ts`
- **同一個交易**內也寫入 `outbox` 表

---

## 第 4 站：事件送出（非同步）

**檔案**：`src/workers/outbox.worker.ts:20`

每 500ms 掃 `outbox` 表中未送出的列，發到 Kafka 後標記已送出。

為什麼要這麼麻煩？因為「寫 DB」和「發 Kafka」無法在同一個交易裡。
如果先發 Kafka 再寫 DB，DB 失敗時事件已經發出去了，下游會處理一筆不存在的訂單。
→ 詳見 [ADR-0005](../05-decisions/adr/0005-transactional-outbox.md)

---

## 第 5 站：付款回來了

**檔案**：`src/workers/payment-event.consumer.ts:35`

Payment Service 付款成功後發 `payment.succeeded` 事件，我們消費它：

    await this.confirmPaymentUseCase.execute({ orderId, paidAt })

→ `src/application/order/confirm-payment.use-case.ts`
→ 內部呼叫 `order.markAsPaid()` → 觸發狀態機檢查

**狀態機**在 `src/domain/order/state-machine.ts:12`：

    const TRANSITIONS = {
      PENDING_PAYMENT: ['PAID', 'CANCELLED', 'EXPIRED'],
      PAID:            ['SHIPPED', 'CANCELLED'],
      SHIPPED:         ['COMPLETED', 'RETURNED'],
      COMPLETED:       [],
      // ...
    }

要新增狀態？**改這裡就好**，型別系統會逼你補齊其他地方。

---

## 你現在應該知道

- [ ] 業務規則要寫在 `src/domain/`
- [ ] 編排要寫在 `src/application/`
- [ ] 外部呼叫要寫在 `src/infrastructure/`
- [ ] 新增訂單狀態，改 `state-machine.ts`
- [ ] 新增欄位，改 `prisma/schema.prisma` + mapper + domain 物件

## 練習題（建議實作，會 review）

1. 加一個「訂單備註」欄位，從 API 一路存到 DB
2. 加一條規則：單筆訂單金額不得超過 100 萬
3. 找出訂單取消時，庫存在哪裡被釋放的

## 下一步

- [測試怎麼寫](testing.md)
- [開發規範](conventions.md)
- [為什麼架構長這樣](../05-decisions/adr/)
```

---

### 4.7 docs/05-decisions/adr/ ★★★

- **目的**：記錄「為什麼」，避免後人重蹈覆轍或無知地重構
- **讀者**：工程師（尤其是想改動架構的人）
- **長度上限**：每則 1 頁
- **更新觸發**：**任何影響難以逆轉的技術決定**

判斷是否需要寫 ADR 的三個問題：

1. 這個決定三個月後有人會問「為什麼？」嗎？
2. 這個決定改起來要超過一週嗎？
3. 我們有認真考慮過至少兩個選項嗎？

有兩個「是」就寫。

#### 範本 `template.md`

```markdown
# ADR-XXXX: （用一句祈使句寫決定，例如「採用 PostgreSQL 作為主資料庫」）

- **狀態**：Proposed | Accepted | Deprecated | Superseded by ADR-YYYY
- **日期**：2026-08-21
- **決策者**：@a, @b
- **相關**：ADR-0002, issue #123

## 背景

我們面臨什麼問題？有哪些限制條件（時間、人力、既有系統、法規）？
**只寫事實，不寫結論。**

## 考慮過的選項

### 選項 A：（名稱）
- 優點：
- 缺點：
- 成本估計：

### 選項 B：（名稱）
- 優點：
- 缺點：
- 成本估計：

### 選項 C：（名稱）
...

## 決定

我們選擇 **選項 X**。

主要理由是（1～3 點，講清楚哪個因素是決定性的）。

## 後果

### 好的
-

### 壞的（誠實寫，這是最有價值的部分）
-

### 中性 / 需要注意的
- 新人容易誤以為 ⋯⋯，需要在 walkthrough 中特別說明

## 什麼情況下該重新檢視這個決定

- 當日訂單量超過 X
- 當團隊人數超過 Y
- 當 Z 技術成熟到 ⋯⋯
```

#### 實例 `0002-monolith-first.md`

```markdown
# ADR-0002: 訂單服務先做單體，不拆微服務

- **狀態**：Accepted
- **日期**：2025-02-14
- **決策者**：@tech-lead, @architect, @eng-manager

## 背景

2025 年初決定把訂單邏輯從前台系統抽出成獨立服務。當時：

- 後端團隊 6 人，其中 2 人剛到職
- 沒有專職 SRE，維運由工程師輪值
- 既有系統已有 K8s 叢集，但沒有 service mesh 或分散式追蹤
- 業務要求 6 個月內上線，趕上 Q4 檔期

有同仁提議直接拆成「接單」「庫存協調」「狀態管理」三個微服務。

## 考慮過的選項

### 選項 A：三個微服務
- 優點：邊界清楚、可獨立擴展、符合長期方向
- 缺點：需要建置分散式追蹤、跨服務交易、三套 CI/CD、三套告警
- 成本估計：額外 6～8 人週的基礎建設，且會持續產生維運負擔

### 選項 B：單體，但內部嚴格分層
- 優點：開發快、除錯容易、單一交易邊界
- 缺點：擴展只能整包擴、模組邊界靠紀律維持（可能腐化）
- 成本估計：需要導入架構檢查工具（約 2 人日）

### 選項 C：維持在前台系統內，只做重構
- 優點：成本最低
- 缺點：無法解決部署耦合，前台改版會影響訂單
- 成本估計：3 人週

## 決定

選擇 **選項 B：單體 + 嚴格內部分層**。

決定性因素：
1. 團隊規模與維運能量不足以支撐三套服務的告警與值班
2. 訂單建立需要交易保證，跨服務會被迫引入 saga，複雜度暴增
3. 模組邊界可以先用「目錄結構 + 靜態檢查」維持，未來要拆的成本可控

## 後果

### 好的
- 4 個月上線，比預期快
- 下單流程可以在單一 DB 交易內完成，不需要補償邏輯
- 新人只需要理解一個 repo

### 壞的
- 尖峰期只能整體擴展，資源浪費約 30%
- 需要人為維持分層紀律，已發生過 2 次違規（靠 lint-arch 攔下）
- 若未來要拆，`application/` 層需要大改

### 中性
- 我們在 `src/modules/` 下以未來的服務邊界劃分目錄，方便日後切割

## 什麼情況下該重新檢視

- 後端團隊超過 15 人，且出現明顯的 merge 衝突瓶頸
- 日訂單量超過 50,000 筆，單一 DB 成為瓶頸
- 有專職 platform team 可承接微服務基礎建設
```

#### ADR 索引 `adr/README.md`

```markdown
# 架構決策紀錄 ADR

| 編號 | 標題 | 狀態 | 日期 |
|---|---|---|---|
| 0001 | 採用 PostgreSQL 作為主資料庫 | Accepted | 2025-01-20 |
| 0002 | 訂單服務先做單體，不拆微服務 | Accepted | 2025-02-14 |
| 0003 | 訂單使用事件溯源 | Superseded by 0007 | 2025-03-02 |
| 0004 | 不使用分散式交易 | Accepted | 2025-03-15 |
| 0005 | 採用 Transactional Outbox 發送事件 | Accepted | 2025-03-15 |
| 0007 | 改用一般狀態機取代事件溯源 | Accepted | 2025-09-10 |

## 規則

- **不要修改已 Accepted 的 ADR 的決定內容**。要改就寫新的，把舊的標記為 Superseded
- 編號只增不減，被廢棄的編號不重用
- Proposed 狀態的 ADR 可以進 PR 討論，合併時改為 Accepted
```

---

### 4.8 docs/04-operations/runbook.md

- **目的**：讓半夜被叫起來的人（可能不是原作者）能處理問題
- **讀者**：值班工程師、SRE
- **長度上限**：每個情境半頁
- **更新觸發**：**每次 incident 事後檢討，必須新增或修訂一則**

```markdown
# Runbook

> 半夜被叫醒時看這份。優先照做，不要先理解原理。

## 先做這三件事

1. 看 [Grafana 訂單服務看板](https://...)
2. 看 [最近部署紀錄](https://...) — 30 分鐘內有部署嗎？有 → 先考慮回滾
3. 在 #incident-order 發一則：「我在看了，目前狀況：⋯」

## 緊急回滾

    kubectl rollout undo deployment/order-service -n production
    kubectl rollout status deployment/order-service -n production

驗證：`curl https://api.internal/orders/health` 應回 200。

---

## 情境：訂單建立失敗率飆高

**告警名稱**：`OrderCreateErrorRateHigh`
**影響**：使用者無法下單，直接損失營收。**P1**

### 判斷

    # 看錯誤分佈
    kubectl logs -l app=order-service --since=10m | grep ERROR | \
      jq -r '.error.code' | sort | uniq -c | sort -rn

| 錯誤碼 | 原因 | 跳到 |
|---|---|---|
| `CATALOG_TIMEOUT` | Catalog Service 慢 | ↓ A |
| `INVENTORY_UNAVAILABLE` | Inventory Service 掛了 | ↓ B |
| `DB_CONNECTION_POOL_EXHAUSTED` | DB 連線用盡 | ↓ C |
| 其他 / 混雜 | 可能是我們自己的 bug | 考慮回滾 |

### A. Catalog 逾時

1. 確認對方狀態：#catalog-eng 詢問，或看他們的看板
2. 熔斷器應該已經開路，檢查：`curl localhost:3000/internal/circuit-breakers`
3. 若對方短時間無法恢復，可暫時放寬 timeout：
   `kubectl set env deployment/order-service CATALOG_TIMEOUT_MS=8000`
4. **不要**關閉驗價（會導致價格錯誤，比不能下單更嚴重）

### B. Inventory 不可用

1. 系統會自動切換為**保守模式**（拒絕所有下單），這是預期行為
2. 確認保守模式已啟動：log 中應出現 `Entering conservative mode`
3. 若沒有自動切換，手動開：
   `kubectl set env deployment/order-service CONSERVATIVE_MODE=true`
4. 通知 #commerce-ops，請前台掛維護公告
5. Inventory 恢復後，關閉保守模式並觀察 10 分鐘

**為什麼不放行？** 超賣的事後處理成本（人工道歉、退款、商譽）遠大於暫時不能下單。
這是產品負責人在 2025-11 明確的決定。

### C. DB 連線用盡

1. 看目前連線數：
   `SELECT count(*), state FROM pg_stat_activity WHERE datname='orders' GROUP BY state;`
2. 找長時間執行的查詢：
   `SELECT pid, now()-query_start AS dur, query FROM pg_stat_activity
    WHERE state='active' AND now()-query_start > interval '30 seconds';`
3. 若是已知的客服後台大查詢（見技術債 #189），可 kill：
   `SELECT pg_terminate_backend(<pid>);`
4. 若是全面性的，擴 pod 沒用（會更糟），改為**縮**到 3 個 pod 讓連線數下降

---

## 情境：訂單狀態卡在「處理中」

**影響**：客戶已付款但看不到出貨。P2。

### 判斷

    -- 找卡超過 30 分鐘的
    SELECT id, status, updated_at FROM orders
    WHERE status='PAID' AND updated_at < now() - interval '30 minutes';

### 處理

1. 檢查 outbox 是否積壓：
   `SELECT count(*) FROM outbox WHERE published_at IS NULL;`
   > 100 表示 outbox worker 有問題 → 看 worker log，必要時重啟
2. 檢查 Kafka consumer lag：
   `kafka-consumer-groups --describe --group order-service`
3. 若確認事件遺失，可手動重發：
   `npm run cli -- republish-order-events --order-id=<id>`
   （此指令冪等，重複執行安全）

---

## 情境：疑似超賣

**影響**：需要人工處理，且有商譽風險。P1。**必須通知產品負責人。**

1. **先止血**：開啟保守模式，停止接單
2. 盤點差異：
   `npm run cli -- audit-stock --sku=<sku>`
3. 匯出受影響訂單，交給 #commerce-ops 走人工處理流程
4. 事後必須寫 postmortem，並在此 runbook 新增對應情境

---

## 聯絡與升級

| 情況 | 找誰 |
|---|---|
| 15 分鐘無進展 | 升級給 @tech-lead |
| 涉及金流 | #payment-eng（有 24h 值班） |
| 需要對外公告 | @product-owner + #commerce-ops |
| 資料可能外洩 | **立刻** @security-oncall |

## Postmortem 規則

P1 事件 48 小時內必須完成 postmortem，並且：
- 在此 runbook 新增或修訂對應情境
- 若牽涉架構問題，寫一則 ADR
```

---

### 4.9 其他文件的重點規格（簡述）

| 文件 | 目的 | 一定要有的東西 | 更新觸發 |
|---|---|---|---|
| `CONTRIBUTING.md` | 開發規範 | 分支命名、commit 格式、PR 檢查清單、review SLA | 流程改變 |
| `local-setup.md` | 環境建置 | 前置需求版本、常見失敗與解法、**最後驗證日期** | 依賴升級 |
| `code-map.md` | 目錄導覽 | 每個目錄一行說明 + 「新增 X 功能該改哪些檔案」對照表 | 目錄結構改變 |
| `data-model.md` | 資料模型 | ER 圖（Mermaid）+ 每張表的用途 + 為什麼這樣正規化 | schema 改變 |
| `state-machine.md` | 狀態機 | 狀態圖 + 每個轉移的觸發條件與副作用 | 狀態改變 |
| `testing.md` | 測試策略 | 測試金字塔比例、各層怎麼寫、如何跑、fixture 在哪 | 測試工具改變 |
| `conventions.md` | 程式規範 | 命名、錯誤處理、log 格式、null 處理原則 | 團隊共識改變 |
| `api-guide.md` | API 補充 | 認證方式、分頁慣例、錯誤碼表、rate limit、版本策略 | API 改變 |
| `events.md` | 事件契約 | 每個事件的 schema、發送時機、消費者清單 | 事件改變 |
| `alerts.md` | 告警清單 | 每則告警：意義、嚴重度、對應 runbook 章節 | 告警調整 |
| `deployment.md` | 部署 | 環境清單、部署流程、回滾方式、feature flag 用法 | 流程改變 |
| `security.md` | 資安 | 威脅模型、PII 欄位清單、加密方式、稽核 log | 每季複審 |
| `permissions.md` | 權限 | 角色 × 操作的矩陣表 | 權限改變 |
| `faq.md` | 常見問題 | 跨部門最常問的 10 題 | 被問第 3 次就加一題 |

---

## 5. 維護機制

文件的敵人不是「沒寫」，是「寫完就過期」，然後大家學會不信任它。

### 5.1 每份文件的檔頭

所有文件開頭統一放：

```markdown
> **維護者**：@github-handle
> **最後更新**：2026-08-21
> **複審週期**：每季 / 每次相關 PR / 不需要
```

沒有維護者的文件 = 沒人負責的文件 = 過期的文件。

### 5.2 綁進 PR 檢查清單

`.github/pull_request_template.md`：

```markdown
## 文件檢查

- [ ] 改了 API → 更新 `docs/03-api/`
- [ ] 改了資料表 → 更新 `docs/01-architecture/data-model.md`
- [ ] 改了訂單狀態 → 更新 `state-machine.md` + `user-journey.md` 的狀態表
- [ ] 引入新的領域名詞 → 加入 `glossary.md`
- [ ] 做了難以逆轉的技術決定 → 新增 ADR
- [ ] 使用者可見的變更 → 更新 `CHANGELOG.md`（用非工程師看得懂的話）
- [ ] 改了本機環境設定 → 更新 `local-setup.md` 並更新驗證日期
- [ ] 以上皆不適用
```

### 5.3 自動化檢查

**CI 中可以做的：**

```yaml
# .github/workflows/docs.yml
- name: 檢查文件連結
  run: npx markdown-link-check docs/**/*.md

- name: 檢查文件過期
  run: node scripts/check-doc-freshness.js  # 讀檔頭的「最後更新」，超過 90 天警告

- name: 檢查 OpenAPI 與程式一致
  run: npm run openapi:diff  # 生成的 spec 與 committed 版本不同就失敗

- name: 檢查架構分層
  run: npx depcruise --validate .dependency-cruiser.js src
```

**用 CODEOWNERS 強制 review：**

```
# .github/CODEOWNERS
/docs/00-overview/    @product-owner @tech-lead
/docs/05-decisions/   @tech-lead @architect
/docs/04-operations/  @sre-team
```

### 5.4 定期儀式

| 頻率 | 做什麼 | 誰 |
|---|---|---|
| 每次 incident 後 | 更新 runbook | 值班者 |
| 每次新人到職 | 新人邊看邊改，把卡住的地方寫進文件 | 新人 |
| 每月 | 檢查過期警告清單 | 輪值 |
| 每季 | 刪除審查：三個月沒人看的文件砍掉 | Tech Lead |
| 每半年 | ADR 複審：有哪些該標 Deprecated | Tech Lead |

**新人到職是最好的文件測試。** 讓新人的第一個 PR 就是修文件——他們是唯一能發現「這裡看不懂」的人，而且這個能力兩週後就會消失。

---

## 6. CLAUDE.md 設定

放在專案根目錄，Claude Code 會自動讀取。

```markdown
# 專案規則

## 專案簡介

訂單服務。單體 Node.js + TypeScript + PostgreSQL + Kafka。
架構採嚴格分層，詳見 `docs/01-architecture/architecture.md`。

## 開始任何工作前

1. 若涉及領域名詞，先讀 `docs/00-overview/glossary.md`，使用表中定義的英文代號
2. 若涉及架構，先讀 `docs/01-architecture/architecture.md` 與相關 ADR
3. 若不確定某個設計為什麼這樣，搜尋 `docs/05-decisions/adr/` 再問我

## 分層規則（違反會被 CI 擋下）

- `src/domain/` 不得 import 任何框架、DB、HTTP 套件。純 TypeScript
- `src/api/` 不得直接存取 DB，必須經過 application 層
- 業務規則只能寫在 `src/domain/`
- 外部呼叫只能寫在 `src/infrastructure/`

## 文件同步規則

修改程式時，一併更新對應文件，放在同一個 PR：

| 你改了 | 就要更新 |
|---|---|
| `src/api/routes/` | `docs/03-api/api-guide.md` |
| `prisma/schema.prisma` | `docs/01-architecture/data-model.md` |
| `src/domain/order/state-machine.ts` | `docs/01-architecture/state-machine.md` 與 `docs/00-overview/user-journey.md` 的狀態表 |
| 引入新套件 / 改變資料流 | 新增 `docs/05-decisions/adr/` |
| 使用者可見的行為 | `CHANGELOG.md`，用非工程師看得懂的敘述 |
| 本機環境設定 | `docs/02-development/local-setup.md`，並更新檔頭的驗證日期 |
| 新的領域名詞 | `docs/00-overview/glossary.md` |

## 註解規則

- **不要寫「這段在做什麼」的註解**——程式碼自己會說。如果看不懂，改名字或拆函式
- **要寫「為什麼」的註解**，尤其是：繞路的作法、效能取捨、外部系統的怪癖
- 註解中若涉及設計決定，加上 ADR 連結：`// 見 ADR-0005`
- 公開 API 的函式要有 JSDoc，內部函式不需要

範例：

    // 不好
    // 迴圈處理每個品項
    for (const item of items) { ... }

    // 好
    // Catalog API 一次最多接受 50 個 SKU，超過會靜默截斷（他們的 bug，已回報 CAT-882）
    for (const chunk of chunk(items, 50)) { ... }

## 寫文件時的語氣

- 給非工程師的文件（`docs/00-overview/`）：不得出現類別名稱、檔案路徑、程式碼
- 給工程師的文件：一定要附檔案路徑與行號
- 一律使用繁體中文，技術名詞保留英文

## 測試

- domain 層必須有單元測試，不得使用 mock DB
- 每個 use case 至少一個 happy path + 一個失敗路徑的整合測試
- 測試名稱用敘述句：`should_reject_order_with_more_than_100_items`
```

### 6.1 好用的 Claude Code 指令

**逆向補文件（對既有專案最有用）：**

```
請閱讀 src/ 整個目錄，推測當初可能做過哪些架構決策。
以 ADR 格式列出，每則標註信心程度（高/中/低），
並明確標出哪些是你的推測、需要我確認。
先不要寫檔案，列清單給我看。
```

**產生 walkthrough：**

```
請追蹤 POST /orders 這個請求的完整路徑，
從路由進入點一路到資料庫寫入與事件發送。
輸出格式：每一站包含「檔案路徑:行號」、這一站在做什麼、
新手常犯的錯誤。目標讀者是到職第三天的後端工程師。
```

**同一段程式，兩種讀者：**

```
（第一次）請用完全不懂技術的營運同事能懂的方式，
說明 src/domain/order/ 這個模組在做什麼。
不要出現任何類別名稱、檔案名稱或程式碼。用比喻可以。

（第二次）請為 src/domain/order/ 寫一份給新手後端工程師的說明，
包含檔案路徑、核心抽象、以及「我想加一個新狀態該怎麼做」。
```

**產生圖表（Mermaid 可進版控、可 diff）：**

```
請為訂單服務產生一張 Mermaid sequenceDiagram，
畫出下單到付款成功的完整流程，包含外部系統。
給工程師看，要標出同步/非同步呼叫。

另外產生一張 C4 Level 1 的 graph，只到系統邊界，
給 PM 看，不要出現任何技術名詞。
```

**維護名詞表：**

```
請掃描 src/domain/ 下所有型別與類別名稱，
與 docs/00-overview/glossary.md 比對，
列出：(1) 程式中有但名詞表沒有的 (2) 名詞表有但程式中用了不同名字的。
```

**文件健檢：**

```
請比對 docs/ 下所有文件中提到的檔案路徑，
列出已經不存在或已改名的路徑，以及它們出現在哪份文件的第幾行。
```

---

## 7. 導入路線圖

不要一次做完。按這個順序，每個階段都能單獨產生價值。

### 第 1 週：止血（3 份）

| 文件 | 為什麼先做 |
|---|---|
| `README.md` 的「5 分鐘跑起來」 | 決定新人第一天的心情，也最容易驗證對錯 |
| `glossary.md` | 成本最低、跨部門收益最高。開會時直接開這份 |
| `runbook.md` 的前三個情境 | 只寫「最近三個月真的發生過」的事件 |

**驗收方式**：找一個沒碰過這專案的人，照 README 跑一次。跑不起來就改到跑得起來。

### 第 1 個月：讓新人自己上手（4 份）

- `overview.md` — 一頁紙
- `architecture.md` — 架構總覽
- `walkthrough.md` — 一條主流程追碼
- `CLAUDE.md` — 讓 AI 幫你維持一致性

**驗收方式**：下一個新人到職，不許口頭教學，只給文件。記錄他卡在哪，那就是要補的地方。

### 第 1 季：制度化

- 補齊 ADR（先寫**未來**的決定，過去的慢慢補）
- 導入 PR 檢查清單與 CODEOWNERS
- `user-journey.md`、`data-model.md`、`state-machine.md`
- CI 加上連結檢查與過期檢查

### 第 2 季以後：按需補齊

- 有外部串接需求 → `integration-guide.md`
- 有稽核需求 → `security.md`、`permissions.md`
- 團隊變大 → `conventions.md`、`code-map.md`

---

## 8. 文件健康度檢查

每季自問這 10 題，答「否」的就是下一季的工作項目。

| # | 問題 | 是/否 |
|---|---|---|
| 1 | 新人能不能不問任何人，就把專案跑起來？ | |
| 2 | 新人的第一個 PR 能不能在第 3 天送出？ | |
| 3 | PM 能不能自己判斷「這個需求大概屬於哪個系統」？ | |
| 4 | 半夜值班的人（非原作者）能不能靠 runbook 處理前三大常見故障？ | |
| 5 | 有人問「為什麼當初這樣設計」時，能不能指到一份 ADR？ | |
| 6 | 過去三個月，有沒有任何一份文件因為程式改動而被同步更新？ | |
| 7 | 有沒有任何一份文件，你會不好意思給外人看（因為太舊）？ | |
| 8 | 跨部門會議中，有沒有發生過「我們講的是同一件事嗎」？ | |
| 9 | 每份文件都有明確的維護者嗎？ | |
| 10 | 過去一季有沒有刪掉任何文件？（都沒刪 = 沒在審查） | |

### 三個危險訊號

1. **文件越來越多，但大家都用問的** → 文件沒被信任，通常是因為過期
2. **只有一個人在寫文件** → 那個人離職時文件就死了
3. **文件寫得很漂亮但沒有「壞的後果」段落** → 是行銷文案不是工程文件

---

## 附錄：一頁式速查

| 讀者 | 給他這 3 份 |
|---|---|
| 非工程師 | `overview.md`、`glossary.md`、`user-journey.md` |
| 新手工程師 | `README.md`（5 分鐘跑起來）、`walkthrough.md`、`architecture.md` |
| 資深工程師 | `adr/`、`architecture.md` 的 Trade-offs、`data-model.md` |
| 值班 | `runbook.md`、`alerts.md` |

| 如果只能做 3 份 | 理由 |
|---|---|
| `glossary.md` | 成本最低，跨部門收益最高 |
| README 的「5 分鐘跑起來」 | 對新人的第一印象影響最大 |
| `walkthrough.md` | 投報率大於所有註解總和 |

| 三個核心規則 |
|---|
| 一份文件只服務一種讀者 |
| 文件與程式同一個 PR |
| 少而準，勝過多而舊 |
